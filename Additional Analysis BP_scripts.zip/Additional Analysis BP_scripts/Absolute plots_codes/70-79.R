library(grid)
library(readxl)
library(dplyr)
library(meta)
library(tidyverse)

# load our dataset

f <- read_excel("subgroup_analaysis 1/11414789/follow up KQ1_updated.xlsx")

d<- read_excel("subgroup_analaysis 1/11414789/ACP KQ1_all studies v7_Final_DP(bp goals).xlsx")
l <- read_csv("subgroup_analaysis 1/11414789/reshaped_main_with_all_RoB(Sheet1).csv")

#  Merge them 
merged <- l |>
  left_join(d, by = "Study") |>
  left_join(f, by = "Study")      # third table

merged <- merged %>%
  mutate(`Lower (DBP)` = as.numeric(as.character(`Lower (DBP)`))) %>%
  filter(!is.na(`Lower (DBP)`))

merged <- merged %>% 
  mutate(
    DBP_goal = case_when(
      !is.na(`Lower (DBP)`) & `Lower (DBP)` >=70 & `Lower (DBP)` < 80 ~ "70-79",
      TRUE ~ NA_character_
    )
  )

merged_cl <- merged %>%
  mutate(`Lower (DBP)` = as.numeric(as.character(`Lower (DBP)`))) %>%
  filter(!is.na(`Lower (DBP)`))

colnames(merged_cl)


num_cols <- c(
  "ACM_low", "nTOT_low", "ACM_control", "nTOT_control",
  "CVM_low", "CVM_control",
  "MCVE_low", "MCVE_control",  
  "stroke_low", "stroke_control",
  "kidney_low", "nTOT_kidney_low", "kidney_control", "nTOT_kidney_control", 
  "syncope_low", "syncope_control", 
  "ortho_low", "nTOT_ortho_low", "ortho_control", "nTOT_ortho_control",
  "falls_low", "nTOT_falls_low", "falls_control", "nTOT_falls_control"
)

descriptive_vars <- c(
  "age (mean)", "DBP_goal", 
  "Study", "Year...4"
)

meta_data <- merged_cl%>%
  select(Study, all_of(num_cols), all_of(descriptive_vars))


view(meta_data)

meta_clin <- meta_data %>%
  # Force numeric for all meta-analysis variables
  mutate(across(all_of(num_cols), ~as.numeric(as.character(.)))) %>%
  # Ensure subgroup variable is a clean character string
  mutate(DBP_goal = trimws(as.character(DBP_goal))) %>%
  # Keep only rows where ALL required variables are non-NA
  filter(complete.cases(across(c("DBP_goal"))))

View(meta_clin)
str(meta_clin)  # suppose to have all outcome columns in numeric and 5 rows

data_clean <- meta_clin


library(shiny)
library(meta)
library(ggplot2)

# Function to compute threshold units
TU_from_RD_piecewise <- function(RD, t1, t2, t3) {
  w1 <- t1
  w2 <- t2 - t1
  w3 <- t3 - t2
  rd <- pmax(0, RD)  # Clamp negatives to 0
  ifelse(rd < t1, rd / w1,
         ifelse(rd < t2, 1 + (rd - t1) / w2,
                ifelse(rd < t3, 2 + (rd - t2) / w3,
                       3 + (rd - t3) / w3)))
}

# For undesirable events: RD > 0 (fewer per 1000) = benefit -> negative TU
signed_TU_dich_undesirable <- function(rd_per1000, t1, t2, t3) {
  if (!is.finite(rd_per1000)) return(NA_real_)
  if (abs(rd_per1000) < 1e-12) return(0)
  mag_TU <- TU_from_RD_piecewise(abs(rd_per1000), t1, t2, t3)
  is_benefit <- rd_per1000 > 0
  ifelse(is_benefit, -mag_TU, +mag_TU)
}

# Create data frame from meta-analysis results
create_df_from_meta <- function(meta_result) {
  if (is.null(meta_result)) return(NULL)
  data.frame(
    Study = meta_result$studlab,
    IntEvents = meta_result$event.e,
    IntTotal = meta_result$n.e,
    ConEvents = meta_result$event.c,
    ConTotal = meta_result$n.c,
    stringsAsFactors = FALSE
  )
}

# Compute TU data frame from meta results with proper ordering
compute_TU_df_from_meta <- function(meta_result, baseline_per1000, t1, t2, t3) {
  if (is.null(meta_result)) return(NULL)
  
  df <- create_df_from_meta(meta_result)
  if (is.null(df)) return(NULL)
  
  # Check 'data_clean' and 'Year...4' column
  if (!exists("data_clean")) {
    stop("Main dataset 'data_clean' not found")
  }
  if (!"Year...4" %in% colnames(data_clean)) {
    stop("Column 'Year...4' not found in the main dataset. Available columns: ", 
         paste(colnames(data_clean), collapse = ", "))
  }
  
  # Merge to get Year for ordering
  df_merged <- merge(df, data_clean[, c("Study", "Year...4")], by = "Study", all.x = TRUE)
  df_ordered <- df_merged[order(df_merged$"Year...4", df_merged$Study), ]
  meta_indices <- match(df_ordered$Study, meta_result$studlab)
  
  RR <- exp(meta_result$TE[meta_indices])
  RR_l <- exp(meta_result$TE[meta_indices] - 1.96 * meta_result$seTE[meta_indices])
  RR_u <- exp(meta_result$TE[meta_indices] + 1.96 * meta_result$seTE[meta_indices])
  
  RD <- baseline_per1000 * (1 - RR)
  RD_l <- baseline_per1000 * (1 - RR_l)
  RD_u <- baseline_per1000 * (1 - RR_u)
  
  RR_pool <- exp(meta_result$TE.random)
  RR_lci <- exp(meta_result$lower.random)
  RR_uci <- exp(meta_result$upper.random)
  
  RR_lpi <- if (!is.null(meta_result$lower.predict)) exp(meta_result$lower.predict) else NA_real_
  RR_upi <- if (!is.null(meta_result$upper.predict)) exp(meta_result$upper.predict) else NA_real_
  
  RD_pool <- baseline_per1000 * (1 - RR_pool)
  RD_lci <- baseline_per1000 * (1 - RR_lci)
  RD_uci <- baseline_per1000 * (1 - RR_uci)
  RD_pil <- if (is.finite(RR_lpi)) baseline_per1000 * (1 - RR_lpi) else NA_real_
  RD_piu <- if (is.finite(RR_upi)) baseline_per1000 * (1 - RR_upi) else NA_real_
  
  TU_study <- sapply(RD, function(x) signed_TU_dich_undesirable(x, t1, t2, t3))
  TU_l_st <- sapply(RD_l, function(x) signed_TU_dich_undesirable(x, t1, t2, t3))
  TU_u_st <- sapply(RD_u, function(x) signed_TU_dich_undesirable(x, t1, t2, t3))
  
  TU_pool <- signed_TU_dich_undesirable(RD_pool, t1, t2, t3)
  TU_lci <- signed_TU_dich_undesirable(RD_lci, t1, t2, t3)
  TU_uci <- signed_TU_dich_undesirable(RD_uci, t1, t2, t3)
  TU_pil <- if (is.finite(RD_pil)) signed_TU_dich_undesirable(RD_pil, t1, t2, t3) else NA_real_
  TU_piu <- if (is.finite(RD_piu)) signed_TU_dich_undesirable(RD_piu, t1, t2, t3) else NA_real_
  
  tudf <- rbind(
    data.frame(
      label = df_ordered$Study,
      type = "study",
      TU = TU_study,
      lci = pmin(TU_l_st, TU_u_st, na.rm = TRUE),
      uci = pmax(TU_l_st, TU_u_st, na.rm = TRUE),
      pil = NA_real_,
      piu = NA_real_,
      stringsAsFactors = FALSE
    ),
    data.frame(
      label = "Pooled",
      type = "pooled",
      TU = TU_pool,
      lci = min(TU_lci, TU_uci, na.rm = TRUE),
      uci = max(TU_lci, TU_uci, na.rm = TRUE),
      pil = if (all(is.finite(c(TU_pil, TU_piu)))) min(TU_pil, TU_piu) else NA_real_,
      piu = if (all(is.finite(c(TU_pil, TU_piu)))) max(TU_pil, TU_piu) else NA_real_,
      stringsAsFactors = FALSE
    )
  )
  
  return(tudf)
}

# Plot function with proper ordering (oldest studies at top)
plot_thresholds_forest <- function(tudf, outcome_name) {
  if (is.null(tudf) || !nrow(tudf)) return(NULL)
  
  study_rows <- tudf[tudf$type == "study", ]
  studies <- study_rows$label
  
  y_map <- data.frame(
    label = c("Pooled", studies),
    y = c(0, rev(2 + seq_along(studies) - 1))
  )
  
  tudf <- merge(tudf, y_map, by = "label", all.x = TRUE, sort = FALSE)
  tudf$y <- as.numeric(tudf$y)
  
  y_pi  <- -0.80
  y_min <- min(-1.2, y_pi - 0.2)
  y_max <- max(y_map$y) + 0.6
  
  g <- ggplot(tudf, aes(x = TU, y = y))
  
  bands <- data.frame(
    xmin = c(-Inf,-3,-2,-1, 1, 2, 3),
    xmax = c( -3, -2, -1,  1, 2, 3, Inf),
    ymin = y_min, ymax = y_max,
    fill = c("#CADBE3","#D7E4EA","#E4EDF1","#FFFFFF","#FFE1C2","#FFD6AD","#FFC285")
  )
  
  g <- g +
    geom_rect(data = bands, aes(xmin = xmin, xmax = xmax, ymin = ymin, ymax = ymax, fill = fill),
              inherit.aes = FALSE, colour = NA, alpha = 0.6, show.legend = FALSE) +
    scale_fill_identity() +
    geom_vline(xintercept = 0, linetype = 2) +
    geom_vline(xintercept = c(-3,-2,-1,1,2,3), linetype = "dotted", linewidth = 0.5)
  
  g <- g +
    geom_errorbarh(
      data = subset(tudf, type == "study" & is.finite(lci) & is.finite(uci)),
      aes(xmin = lci, xmax = uci),
      height = 0.14, linewidth = 0.9, colour = "grey65"
    ) +
    geom_point(
      data = subset(tudf, type == "study" & is.finite(TU)),
      size = 2.8, stroke = 0, colour = "grey35"
    )
  
  pooled <- subset(tudf, type == "pooled")
  if (nrow(pooled) == 1) {
    if (is.finite(pooled$pil) && is.finite(pooled$piu)) {
      g <- g + geom_segment(
        data = pooled, aes(x = pil, xend = piu, y = -0.80, yend = -0.80),
        inherit.aes = FALSE, linewidth = 1.6, colour = "red3", lineend = "butt"
      )
    }
    g <- g + geom_errorbarh(
      data = pooled, aes(y = 0, xmin = lci, xmax = uci),
      inherit.aes = FALSE, height = 0.30, linewidth = 1.5, colour = "grey20"
    )
    d <- 0.18
    poly <- data.frame(
      x = c(pooled$TU - d, pooled$TU, pooled$TU + d, pooled$TU),
      y = c(0, 0 + 0.25, 0, 0 - 0.25)
    )
    g <- g + geom_polygon(data = poly, aes(x = x, y = y),
                          inherit.aes = FALSE, fill = "grey25")
  }
  
  y_breaks <- c(0, 1, unique(tudf$y[!is.na(tudf$y) & tudf$y >= 2]))
  y_labs   <- c("Pooled", "", as.character(y_map$label[y_map$y >= 2]))
  
  g <- g +
    scale_y_continuous(breaks = y_breaks, labels = y_labs,
                       expand = expansion(mult = 0)) +
    scale_x_continuous(breaks = -3:3,
                       labels = function(x) sprintf("%g", x),
                       expand = expansion(mult = 0.02)) +
    coord_cartesian(xlim = c(-3.99, 3.99), ylim = c(y_min, y_max), clip = "on") +
    labs(x = "Threshold Units", y = NULL, title = paste("Outcome:", outcome_name)) +
    theme_bw() +
    theme(
      panel.background   = element_rect(fill = "white", colour = NA),
      plot.background    = element_rect(fill = "white", colour = NA),
      panel.grid.major.y = element_blank(),
      panel.grid.minor   = element_blank(),
      axis.text.y        = element_text(size = 13, face = "bold"),
      axis.text.x        = element_text(size = 13, face = "bold"),
      plot.title         = element_text(hjust = 0.5, size = 14, face = "bold"),
      plot.margin        = margin(40, 90, 46, 90)
    )
  
  return(g)
}

# UI definition
ui <- fluidPage(
  tags$head(tags$style("body { background: #f8f9fa; } .well{background:#fff;border:1px solid #dee2e6;}")),
  titlePanel("Absolute Effects with Threshold Units - Meta-Analysis Results"),
  sidebarLayout(
    sidebarPanel(
      wellPanel(
        h4("Meta-Analysis Settings"),
        selectInput("outcome", "Select Outcome:",
                    choices = c("All-cause mortality" = "ACM",
                                "Cardiovascular mortality" = "CVM", 
                                "Major CV events" = "MCVE",
                                "Stroke" = "stroke",
                                "Kidney function loss" = "kidney",
                                "Syncope" = "syncope",
                                "Orthostatic hypotension" = "ortho",
                                "Falls" = "falls")),
        numericInput("baseline_per1000", "Baseline risk per 1000", value = 100, min = 1, step = 1),
        tags$hr(),
        h4("Decision Thresholds"),
        numericInput("thr_t1", "t1 (trivial→small)", value = 10, min = 1, step = 1),
        numericInput("thr_t2", "t2 (small→moderate)", value = 30, min = 2, step = 1),
        numericInput("thr_t3", "t3 (moderate→large)", value = 60, min = 3, step = 1),
        actionButton("plot_abs_effect", "Generate Plot", class = "btn btn-primary")
      )
    ),
    mainPanel(
      plotOutput("abs_plot", height = "700px"),
      tags$hr(),
      # >>> ADDED DOWNLOAD BUTTONS <<<
      downloadButton("download_png", "Download PNG"),
      downloadButton("download_pdf", "Download PDF"),
      tags$hr(),
      
      verbatimTextOutput("meta_summary")
    )
  )
)

# Server logic
server <- function(input, output, session) {
  
  run_meta_analysis <- reactive({
    outcome <- input$outcome
    
    # Subset data_clean and run meta-analysis per outcome
    if (outcome == "ACM") {
      data_sub <- subset(data_clean, !is.na(ACM_low) & !is.na(ACM_control))
      meta_result <- metabin(
        event.e = ACM_low, n.e = nTOT_low,
        event.c = ACM_control, n.c = nTOT_control,
        studlab = Study, data = data_sub,
        sm = "RR", method = "Inverse", random = TRUE,
        common = FALSE, method.tau = "REML", incr = "TACC", prediction = TRUE
      )
    } else if (outcome == "CVM") {
      data_sub <- subset(data_clean, !is.na(CVM_low) & !is.na(CVM_control))
      meta_result <- metabin(
        event.e = CVM_low, n.e = nTOT_low,
        event.c = CVM_control, n.c = nTOT_control,
        studlab = Study, data = data_sub,
        sm = "RR", method = "Inverse", random = TRUE,
        common = FALSE, method.tau = "REML", incr = "TACC", prediction = TRUE
      )
    } else if (outcome == "MCVE") {
      data_sub <- subset(data_clean, !is.na(MCVE_low) & !is.na(MCVE_control))
      meta_result <- metabin(
        event.e = MCVE_low, n.e = nTOT_low,
        event.c = MCVE_control, n.c = nTOT_control,
        studlab = Study, data = data_sub,
        sm = "RR", method = "Inverse", random = TRUE,
        common = FALSE, method.tau = "REML", incr = "TACC", prediction = TRUE
      )
    } else if (outcome == "stroke") {
      data_sub <- subset(data_clean, !is.na(stroke_low) & !is.na(stroke_control))
      meta_result <- metabin(
        event.e = stroke_low, n.e = nTOT_low,
        event.c = stroke_control, n.c = nTOT_control,
        studlab = Study, data = data_sub,
        sm = "RR", method = "Inverse", random = TRUE,
        common = FALSE, method.tau = "REML", incr = "TACC", prediction = TRUE
      )
    } else if (outcome == "kidney") {
      data_sub <- subset(data_clean, !is.na(kidney_low) & !is.na(kidney_control))
      meta_result <- metabin(
        event.e = kidney_low, n.e = nTOT_kidney_low,
        event.c = kidney_control, n.c = nTOT_kidney_control,
        studlab = Study, data = data_sub,
        sm = "RR", method = "Inverse", random = TRUE,
        common = FALSE, method.tau = "REML", incr = "TACC", prediction = TRUE
      )
    } else if (outcome == "syncope") {
      data_sub <- subset(data_clean, !is.na(syncope_low) & !is.na(syncope_control))
      meta_result <- metabin(
        event.e = syncope_low, n.e = nTOT_low,
        event.c = syncope_control, n.c = nTOT_control,
        studlab = Study, data = data_sub,
        sm = "RR", method = "Inverse", random = TRUE,
        common = FALSE, method.tau = "REML", incr = "TACC", prediction = TRUE
      )
    } else if (outcome == "ortho") {
      data_sub <- subset(data_clean, !is.na(ortho_low) & !is.na(ortho_control))
      meta_result <- metabin(
        event.e = ortho_low, n.e = nTOT_ortho_low,
        event.c = ortho_control, n.c = nTOT_ortho_control,
        studlab = Study, data = data_sub,
        sm = "RR", method = "Inverse", random = TRUE,
        common = FALSE, method.tau = "REML", incr = "TACC", prediction = TRUE
      )
    } else if (outcome == "falls") {
      data_sub <- subset(data_clean, !is.na(falls_low) & !is.na(falls_control))
      meta_result <- metabin(
        event.e = falls_low, n.e = nTOT_falls_low,
        event.c = falls_control, n.c = nTOT_falls_control,
        studlab = Study, data = data_sub,
        sm = "RR", method = "Inverse", random = TRUE,
        common = FALSE, method.tau = "REML", incr = "TACC", prediction = TRUE
      )
    } else {
      meta_result <- NULL
    }
    
    return(meta_result)
  })
  
  # Generate Threshold Units data frame
  tudf <- eventReactive(input$plot_abs_effect, {
    meta_res <- run_meta_analysis()
    if (is.null(meta_res)) return(NULL)
    compute_TU_df_from_meta(meta_res,
                            baseline_per1000 = input$baseline_per1000,
                            t1 = input$thr_t1,
                            t2 = input$thr_t2,
                            t3 = input$thr_t3)
  })
  
  # Render plot
  plot_obj <- reactive({
    df <- tudf()
    if (is.null(df)) return(NULL)
    plot_thresholds_forest(df, input$outcome)
  })
  
  output$abs_plot <- renderPlot({
    plot_obj()
  })
  
  
  # ============================
  #   DOWNLOAD HANDLERS
  # ============================
  
  output$download_png <- downloadHandler(
    filename = function() {
      paste0(input$outcome, "_plot.png")
    },
    content = function(file) {
      ggsave(
        filename = file,
        plot = plot_obj(),
        width = 10,
        height = 8,
        dpi = 300
      )
    }
  )
  
  output$download_pdf <- downloadHandler(
    filename = function() {
      paste0(input$outcome, "_plot.pdf")
    },
    content = function(file) {
      ggsave(
        filename = file,
        plot = plot_obj(),
        width = 10,
        height = 8,
        device = cairo_pdf
      )
    }
  )
  
  
  # Render meta-analysis summary text
  output$meta_summary <- renderPrint({
    meta_res <- run_meta_analysis()
    if (is.null(meta_res)) {
      cat("No meta-analysis results available for the selected outcome.")
    } else {
      print(summary(meta_res))
    }
  })
}

shinyApp(ui, server)




remove(list = ls())
