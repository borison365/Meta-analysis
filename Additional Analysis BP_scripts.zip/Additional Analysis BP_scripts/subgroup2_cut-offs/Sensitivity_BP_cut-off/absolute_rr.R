
# ========================
# Load required packages
# ========================
install.packages(c("shiny", "meta", "ggplot2"))  # Run once if not installed
library(shiny)
library(meta)
library(ggplot2)

# ========================
# 1. Helper Functions
# ========================

# Function to compute threshold units
TU_from_RD_piecewise <- function(RD, t1, t2, t3) {
  w1 <- t1
  w2 <- t2 - t1
  w3 <- t3 - t2
  rd <- pmax(0, RD)  # clamp negatives to 0
  ifelse(rd < t1, rd / w1,
         ifelse(rd < t2, 1 + (rd - t1) / w2,
                ifelse(rd < t3, 2 + (rd - t2) / w3,
                       3 + (rd - t3) / w3)))
}

# Function for undesirable events: RD > 0 = more events (harm), RD < 0 = fewer events (benefit)
# We flip sign so that benefit (fewer events) = positive TU
signed_TU_dich_undesirable <- function(rd_per1000, t1, t2, t3) {
  if (!is.finite(rd_per1000)) return(NA_real_)
  if (abs(rd_per1000) < 1e-12) return(0)
  
  mag_TU <- TU_from_RD_piecewise(abs(rd_per1000), t1, t2, t3)
  ifelse(rd_per1000 < 0, +mag_TU, -mag_TU)  # Negative RD (benefit) → positive TU
}

# Create study-level data frame from meta-analysis results
create_df_from_meta <- function(meta_r) {
  if (is.null(meta_r)) return(NULL)
  
  data.frame(
    Study = meta_result$studlab,
    IntEvents = meta_r$event.e,
    IntTotal = meta_r$n.e,
    ConEvents = meta_r$event.c,
    ConTotal = meta_r$n.c,
    stringsAsFactors = FALSE
  )
}

# ========================
# 2. Compute Absolute Risk and Threshold Units
# ========================

compute_TU_df_from_meta <- function(meta_r, baseline_per1000, t1, t2, t3) {
  if (is.null(meta_r)) return(NULL)
  df <- create_df_from_meta(meta_r)
  if (is.null(df)) return(NULL)
  
  # Extract RR and CI (not log scale)
  RR <- meta_r$TE
  RR_l <- meta_r$lower
  RR_u <- meta_r$upper
  
  # Absolute risk difference per 1000 (RR - 1)
  RD <- baseline_per1000 * (RR - 1)
  RD_l <- baseline_per1000 * (RR_l - 1)
  RD_u <- baseline_per1000 * (RR_u - 1)
  
  # Pooled estimates
  RR_pool <- meta_r$TE.random
  RR_lci <- meta_r$lower.random
  RR_uci <- meta_r$upper.random
  RR_lpi <- if (!is.null(meta_r$lower.predict)) meta_r$lower.predict else NA_real_
  RR_upi <- if (!is.null(meta_r$upper.predict)) meta_r$upper.predict else NA_real_
  
  RD_pool <- baseline_per1000 * (RR_pool - 1)
  RD_lci <- baseline_per1000 * (RR_lci - 1)
  RD_uci <- baseline_per1000 * (RR_uci - 1)
  RD_pil <- if (is.finite(RR_lpi)) baseline_per1000 * (RR_lpi - 1) else NA_real_
  RD_piu <- if (is.finite(RR_upi)) baseline_per1000 * (RR_upi - 1) else NA_real_
  
  # Threshold Units (TU)
  TU_study <- sapply(RD, function(x) signed_TU_dich_undesirable(x, t1, t2, t3))
  TU_l_st <- sapply(RD_l, function(x) signed_TU_dich_undesirable(x, t1, t2, t3))
  TU_u_st <- sapply(RD_u, function(x) signed_TU_dich_undesirable(x, t1, t2, t3))
  
  TU_pool <- signed_TU_dich_undesirable(RD_pool, t1, t2, t3)
  TU_lci <- signed_TU_dich_undesirable(RD_lci, t1, t2, t3)
  TU_uci <- signed_TU_dich_undesirable(RD_uci, t1, t2, t3)
  TU_pil <- if (is.finite(RD_pil)) signed_TU_dich_undesirable(RD_pil, t1, t2, t3) else NA_real_
  TU_piu <- if (is.finite(RD_piu)) signed_TU_dich_undesirable(RD_piu, t1, t2, t3) else NA_real_
  
  tudf <- rbind(
    data.frame(
      label = df$Study,
      type = "study",
      TU = TU_study,
      lci = pmin(TU_l_st, TU_u_st, na.rm = TRUE),
      uci = pmax(TU_l_st, TU_u_st, na.rm = TRUE),
      pil = NA_real_,
      piu = NA_real_,
      stringsAsFactors = FALSE
    ),
    data.frame(
      label = "Pooled",
      type = "pooled",
      TU = TU_pool,
      lci = min(TU_lci, TU_uci, na.rm = TRUE),
      uci = max(TU_lci, TU_uci, na.rm = TRUE),
      pil = if (all(is.finite(c(TU_pil, TU_piu)))) min(TU_pil, TU_piu) else NA_real_,
      piu = if (all(is.finite(c(TU_pil, TU_piu)))) max(TU_pil, TU_piu) else NA_real_,
      stringsAsFactors = FALSE
    )
  )
  
  return(tudf)
}

# ========================
# 3. Plot Function
# ========================

plot_thresholds_forest <- function(tudf) {
  if (is.null(tudf) || !nrow(tudf)) return(NULL)
  
  studies <- rev(unique(tudf$label[tudf$type == "study"]))
  y_map <- data.frame(label = c("Pooled", studies),
                      y = c(0, 2 + seq_along(studies) - 1))
  tudf <- merge(tudf, y_map, by = "label", all.x = TRUE, sort = FALSE)
  tudf$y <- as.numeric(tudf$y)
  
  y_pi <- -0.80
  y_min <- min(-1.2, y_pi - 0.2)
  y_max <- max(y_map$y) + 0.6
  
  bands <- data.frame(
    xmin = c(-Inf,-3,-2,-1, 1, 2, 3),
    xmax = c(-3, -2, -1,  1, 2, 3, Inf),
    ymin = y_min, ymax = y_max,
    fill = c("#FFE1C2","#FFD6AD","#FFC285","#FFFFFF","#E4EDF1","#D7E4EA","#CADBE3")
  )
  
  g <- ggplot(tudf, aes(x = TU, y = y)) +
    geom_rect(data = bands, aes(xmin = xmin, xmax = xmax, ymin = ymin, ymax = ymax, fill = fill),
              inherit.aes = FALSE, colour = NA, alpha = 0.6, show.legend = FALSE) +
    scale_fill_identity() +
    geom_vline(xintercept = 0, linetype = 2) +
    geom_vline(xintercept = c(-3,-2,-1,1,2,3), linetype = "dotted", linewidth = 0.5) +
    geom_errorbarh(data = subset(tudf, type == "study"), aes(xmin = lci, xmax = uci),
                   height = 0.14, linewidth = 0.9, colour = "grey65") +
    geom_point(data = subset(tudf, type == "study"), size = 2.8, stroke = 0, colour = "grey35")
  
  pooled <- subset(tudf, type == "pooled")
  if (nrow(pooled) == 1) {
    if (is.finite(pooled$pil) && is.finite(pooled$piu)) {
      g <- g + geom_segment(
        data = pooled, aes(x = pil, xend = piu, y = -0.80, yend = -0.80),
        linewidth = 1.6, colour = "red3"
      )
    }
    g <- g + geom_errorbarh(data = pooled, aes(y = 0, xmin = lci, xmax = uci),
                            height = 0.30, linewidth = 1.5, colour = "grey20")
    d <- 0.18
    poly <- data.frame(
      x = c(pooled$TU - d, pooled$TU, pooled$TU + d, pooled$TU),
      y = c(0, 0.25, 0, -0.25)
    )
    g <- g + geom_polygon(data = poly, aes(x = x, y = y),
                          inherit.aes = FALSE, fill = "grey25")
  }
  
  pooled_text <- if (nrow(pooled) == 1) {
    paste0("Pooled: ", sprintf("%.2f", pooled$TU),
           " TU (95% CI ", sprintf("%.2f", pooled$lci),
           " to ", sprintf("%.2f", pooled$uci), ")")
  } else "Pooled estimates not available"
  
  g + 
    scale_y_continuous(breaks = c(0, 1, unique(tudf$y[tudf$y >= 2])),
                       labels = c("Pooled", "", as.character(y_map$label[y_map$y >= 2]))) +
    labs(x = "Threshold Units (positive = benefit)", y = NULL,
         title = "Absolute Effects with Threshold Units",
         caption = pooled_text) +
    theme_bw() +
    theme(plot.title = element_text(hjust = 0.5, face = "bold"),
          plot.caption = element_text(hjust = 0.5, size = 10, face = "bold"))
}

# ========================
# 4. Shiny UI
# ========================

ui <- fluidPage(
  tags$head(tags$style("body { background: #f8f9fa; } .well{background:#fff;border:1px solid #dee2e6;}")),
  titlePanel("Absolute Effects with Threshold Units - Meta-Analysis Results"),
  sidebarLayout(
    sidebarPanel(
      wellPanel(
        h4("Meta-Analysis Settings"),
        numericInput("baseline_per1000", "Baseline risk per 1000", value = 100, min = 1, step = 1),
        h4("Decision Thresholds"),
        numericInput("thr_t1", "t1 (trivial→small)", value = 10, min = 1, step = 1),
        numericInput("thr_t2", "t2 (small→moderate)", value = 30, min = 2, step = 1),
        numericInput("thr_t3", "t3 (moderate→large)", value = 60, min = 3, step = 1),
        actionButton("plot_abs_effect", "Generate Example Plot", class = "btn btn-primary")
      )
    ),
    mainPanel(
      plotOutput("abs_plot", height = "700px"),
      tags$hr(),
      verbatimTextOutput("meta_summary")
    )
  )
)

# ========================
# 5. Shiny Server
# ========================

server <- function(input, output, session) {
  observeEvent(input$plot_abs_effect, {
    # Example fake meta-analysis results
    set.seed(123)
    meta_result <- list(
      studlab = paste("Study", 1:5),
      event.e = sample(10:40, 5),
      n.e = rep(100, 5),
      event.c = sample(20:50, 5),
      n.c = rep(100, 5),
      TE = runif(5, 0.7, 1.3),        # Random RR values (not log)
      lower = runif(5, 0.6, 1.0),
      upper = runif(5, 1.1, 1.6),
      TE.random = 0.9,
      lower.random = 0.8,
      upper.random = 1.1,
      I2 = 35.4, tau2 = 0.01
    )
    
    tudf <- compute_TU_df_from_meta(
      meta_r = meta_r,
      baseline_per1000 = input$baseline_per1000,
      t1 = input$thr_t1, t2 = input$thr_t2, t3 = input$thr_t3
    )
    
    output$abs_plot <- renderPlot({
      plot_thresholds_forest(tudf)
    }, bg = "white", res = 96)
    
    output$meta_summary <- renderPrint({
      cat("Example Meta-Analysis Summary:\n")
      cat("=============================\n")
      cat("Number of studies:", length(meta_r$studlab), "\n")
      cat("Pooled RR:", round(meta_r$TE.random, 3), "\n")
      cat("95% CI:", round(meta_r$lower.random, 3), "to", round(meta_r$upper.random, 3), "\n")
      cat("I²:", round(meta_r$I2, 2), "%\n")
      cat("Tau²:", round(meta_r$tau2, 4), "\n")
    })
  })
}

# ========================
# 6. Run the app
# ========================
shinyApp(ui, server)

