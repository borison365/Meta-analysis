install.packages("grid")
# "tidyverse", "ggplot2", "meta", "grid", "janitor"
library(dplyr)
library(tidyverse)
library(meta)
library(ggplot2)
library(grid)


df<- read_excel("ACP KQ1_all studies v7_Final_DP(bp goals).xlsx")
dh<- read_excel("reshaped_main_with_all_RoB.xlsx")

# left_join keeps all rows from dm, and adds matching rows from bp
merged_dy <- left_join(df, dh, by = "Study")

merged_dy <- merged_dy %>%
  mutate(
    BP_goal_group_SBP = case_when(
      !is.na(`Lower (SBP)`) & `Lower (SBP)` < 120 ~ "<120",
      `Lower (SBP)` >= 120 & `Lower (SBP)` < 130 ~ "120–129",
      `Lower (SBP)` >= 130 & `Lower (SBP)` < 140 ~ "130–139",
      `Lower (SBP)` >= 140 & `Lower (SBP)` < 150 ~ "140–149",
      `Lower (SBP)` >= 150 ~ "≥150",
      TRUE ~ NA_character_
    )
  )
colnames(merged_dy)

merged_j <- merged_dy %>%
  mutate(`Lower (SBP)` = as.numeric(as.character(`Lower (SBP)`))) %>%
  filter(!is.na(`Lower (SBP)`))

nrow(merged_j) # suppose to return 21 rows
# --- Keep descriptive variables ---

num_cols <- c("ACM_low", "nTOT_low", "ACM_control", "nTOT_control")
merged_j[num_cols] <- lapply(merged_j[num_cols], function(x) as.numeric(as.character(x)))
descriptive_vars <- c("age (mean)",  "female (%)" , "high CV risk (%)", "DM (%)" 
                      , "BP_goal_group_SBP")
meta_dal <- merged_j%>%
  select(Study, all_of(num_cols), all_of(descriptive_vars))

#Remove rows where any event column is NA after conversion
meta_dt <- meta_dal %>%
  filter(complete.cases(across(all_of(num_cols))))
nrow(meta_dt)

# 2. Convert to numeric first
merged_j[num_cols] <- lapply(merged_j[num_cols], function(x) as.numeric(as.character(x)))

# 3. Keep descriptive variables and Study
descriptive_vars <- c("age (mean)",  "female (%)" , "high CV risk (%)", "DM (%)", "BP_goal_group_SBP")
meta_dt <- merged_j %>%
  select(Study, all_of(num_cols), all_of(descriptive_vars))

# 4. Remove rows with any NA in numeric columns
meta_dt <- meta_dt %>%
  filter(complete.cases(across(all_of(num_cols))))

view(meta_dt)
# 6. Check lengths
length(meta_dt$ACM_low)
length(meta_dt$BP_goal_group_SBP)

table(is.na(meta_dt$ACM_low))  # should all be FALSE

# Ensure numeric and clean columns
num_cols <- c("ACM_low", "nTOT_low", "ACM_control", "nTOT_control")

meta_clean <- meta_dt %>%
  # Force numeric for all meta-analysis variables
  mutate(across(all_of(num_cols), ~as.numeric(as.character(.)))) %>%
  # Ensure subgroup variable is a clean character string
  mutate(BP_goal_group_SBP = trimws(as.character(BP_goal_group_SBP))) %>%
  # Keep only rows where ALL required variables are non-NA
  filter(complete.cases(across(c(all_of(num_cols), "BP_goal_group_SBP")))) 

# *** ORDER rows by SBP goal ***
meta_clean <- meta_clean %>% arrange(`Lower (SBP)`)

# Ensure subgroup variable is quoted correctly
meta_rr <- metabin(
  event.e = ACM_low,
  n.e = nTOT_low,
  event.c = ACM_control,
  n.c = nTOT_control,
  studlab = Study,
  data = meta_clean,
  sm = "RR",
  method = "Inverse",
  common = FALSE,
  random = TRUE,
  subgroup = meta_clean$BP_goal_group_SBP,
  method.tau = "REML",
  incr = "TACC"
)

forest(
  meta_rr,
  print.byvar = TRUE,
  text.random = "Overall (Random effects)",
  prediction = TRUE,
  print.I2 = TRUE,
  
  smlab = "Risk Ratio (95% CI)",
  xlab = "Risk Ratio"
)
colnames(meta_clean)
View(meta_clean)
#Add descriptive variables to meta object 

meta_rr$`age (mean)`       <- meta_clean$`age (mean)`
meta_rr$`female (%)`       <- meta_clean$`female (%)`
meta_rr$`high CV risk (%)` <- meta_clean$`high CV risk (%)`
meta_rr$`DM (%)`           <- meta_clean$`DM (%)`


# Forest plot in pdf
pdf("forest_metaACM_rr.pdf", width = 16, height = 7)

forest(
  meta_rr,
  label.e = "Lower BP goals",
  label.c = "Higher BP goals",
  
  # Left columns
  leftcols = c("studlab",
               "event.e", "n.e", "event.c", "n.c",
               "age (mean)", "female (%)", "high CV risk (%)",
               "DM (%)"),
  leftlabs = c("Study",
               "Events", "Total", "Events", "Total",
               "Age (mean)", "Female (%)", "High CV risk (%)",
               "DM (%)"
               ) ,
  
  comb.fixed = FALSE,     
  comb.random = TRUE,       
  print.study.ci = TRUE,       
  showweights = TRUE,          
  digits = 2,                  # decimals for RR and CI
  # Formatting
  colgap.left = "4mm",
  fontsize = 10,
  plotwidth = "9cm",  
  xlim = c(0.1,10),
  pooled.events = TRUE,
  print.I2.ci = TRUE,
  print.tau2 = TRUE,
  overall.hetstat = TRUE,
  test.overall = TRUE
)

# Title
grid.text(
  "ACM Sensitivity Analysis of Studies by Systolic BP Goal",
  x = unit(0.5, "npc"),
  y = unit(0.97, "npc"),
  gp = gpar(fontsize = 14, fontface = "bold")
)
dev.off()


