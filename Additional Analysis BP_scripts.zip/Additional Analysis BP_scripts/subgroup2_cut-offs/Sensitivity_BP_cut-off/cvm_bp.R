library(grid)
library(dplyr)
library(tidyverse)
library(meta)

f <- read_excel("follow up KQ1.xlsx")


d<- read_excel("ACP KQ1_all studies v7_Final_DP(bp goals).xlsx")
l <- read_excel("reshaped_main_with_all_RoB.xlsx")

merged <- l |>
  left_join(d, by = "Study") |>
  left_join(f, by = "Study")      # third table

merged <- merged %>%
  mutate(
    BP_goal_group_SBP = case_when(
      !is.na(`Lower (SBP)`) & `Lower (SBP)` < 120 ~ "<120",
      `Lower (SBP)` >= 120 & `Lower (SBP)` < 130 ~ "120–129",
      `Lower (SBP)` >= 130 & `Lower (SBP)` < 140 ~ "130–139",
      `Lower (SBP)` >= 140 & `Lower (SBP)` < 150 ~ "140–149",
      `Lower (SBP)` >= 150 ~ "≥150",
      TRUE ~ NA_character_
    )
  )


merged_cl <- merged %>%
  mutate(`Lower (SBP)` = as.numeric(as.character(`Lower (SBP)`))) %>%
  filter(!is.na(`Lower (SBP)`))

nrow(merged_cl) # suppose to return 21 rows
colnames(merged_cl)
# --- Keep descriptive variables ---

num_cols <- c("CVM_low", "nTOT_low", "CVM_control", "nTOT_control")

# force numeric conversion
merged_cl[num_cols] <- lapply(merged_cl[num_cols], \(x) as.numeric(as.character(x)))

descriptive_vars <- c(
  "age (mean)", "female (%)", "high CV risk (%)", "DM (%)",
  "BP_goal_group_SBP",
  "FUP_ACM", "FUP_CVM", "FUP_MCVE",
  "FUP_stroke", "FUP_kidney", "FUP_syncope",
  "FUP_ortho", "FUP_falls",
  "FUP_qol_phy", "FUP_qol_ment",
  "FUP_qol_EQ5D", "FUP_qol_EQVAS"
)
meta_dn <- merged_cl%>%
  select(Study, all_of(num_cols), all_of(descriptive_vars))

#Remove rows where any event column is NA after conversion
meta_dn <- meta_dn %>%
  filter(complete.cases(across(all_of(num_cols))))
nrow(meta_dn)
view(meta_dn)
# 2. Convert to numeric first
meta_dn[num_cols] <- lapply(meta_dn[num_cols], function(x) as.numeric(as.character(x)))

# 4. Remove rows with any NA in numeric columns
meta_dr <- meta_dn %>%
  filter(complete.cases(across(all_of(num_cols))))
colnames(meta_dr)
view(meta_dr)

# 6. Check lengths
length(meta_dr$CVM_low)
length(meta_dr$BP_goal_group_SBP)

table(is.na(meta_dr$CVM_low))  # should all be FALSE

meta_cdm <- meta_dr %>%
  # Force numeric for all meta-analysis variables
  mutate(across(all_of(num_cols), ~as.numeric(as.character(.)))) %>%
  # Ensure subgroup variable is a clean character string
  mutate(BP_goal_group_SBP = trimws(as.character(BP_goal_group_SBP))) %>%
  # Keep only rows where ALL required variables are non-NA
  filter(complete.cases(across(c(all_of(num_cols), "BP_goal_group_SBP")))) 

meta_cvm <- meta_dr %>%
  mutate(across(all_of(num_cols), ~as.numeric(as.character(.)))) %>%
  mutate(BP_goal_group_SBP = trimws(as.character(BP_goal_group_SBP))) %>%
  filter(complete.cases(across(c(all_of(num_cols), "BP_goal_group_SBP")))) 



# arrange studies in the order of bp goal
meta_cvm <- meta_cvm |>
  mutate(
    BP_goal_group_SBP = factor(
      BP_goal_group_SBP,
      levels = c("<120", "120–129", "130–139", "140–149", "≥150")
    )
  ) |>
  arrange(BP_goal_group_SBP)

view(meta_cvm)
colnames(meta_cvm)

# Ensure subgroup variable is quoted correctly
meta_c <- metabin(
  event.e = CVM_low,
  n.e = nTOT_low,
  event.c = CVM_control,
  n.c = nTOT_control,
  studlab = Study,
  data = meta_cvm,
  sm = "RR",
  method = "Inverse",
  common = FALSE,
  random = TRUE,
  subgroup = meta_cvm$BP_goal_group_SBP,
  method.tau = "REML",
  incr = "TACC"
)


forest(
  meta_c,
  print.byvar = TRUE,
  text.random = "Overall (Random effects)",
  prediction = TRUE,
  print.I2 = TRUE,
  
  smlab = "Risk Ratio (95% CI)",
  xlab = "Risk Ratio"
)

#Add descriptive variables to meta object 

meta_c$`age (mean)`       <- meta_c$`age (mean)`
meta_c$`female (%)`       <- meta_c$`female (%)`
meta_c$`high CV risk (%)` <- meta_c$`high CV risk (%)`
meta_c$`DM (%)`           <- meta_c$`DM (%)` 
meta_c$"FUP_CVM"        <- meta_c$"FUP_CVM"

# Forest plot in pdf
pdf("forest_metaACM_rr.pdf", width = 16, height = 7)

forest(
  meta_c,
  label.e = "Lower BP goals",
  label.c = "Higher BP goals",
  
  leftcols = c("studlab",
               "event.e", "n.e", "event.c", "n.c",
               "age (mean)", "female (%)", "high CV risk (%)",
               "DM (%)", "FUP_CVM"),
  leftlabs = c("Study",
               "Events", "Total", "Events", "Total",
               "Age (mean)", "Female (%)", "High CV risk (%)",
               "DM (%)", "FU (months)"),
  
  comb.fixed = FALSE,
  comb.random = TRUE,
  print.study.ci = TRUE,
  showweights = TRUE,
  digits = 2,
  colgap.left = "4mm",
  fontsize = 10,
  plotwidth = "9cm",
  xlim = c(0.1,10),
  pooled.events = TRUE,
  print.I2.ci = TRUE,
  print.tau2 = TRUE,
  overall.hetstat = TRUE,
  test.overall = TRUE
)

# Title
grid.text(
  "Cardiovascular Mortality Sensitivity Analysis by Systolic BP Goal",
  x = unit(0.5, "npc"),
  y = unit(0.95, "npc"),
  gp = gpar(fontsize = 13, fontface = "bold")
)
dev.off()
