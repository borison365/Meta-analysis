
k <- read_excel("follow up KQ1.xlsx")


t<- read_excel("ACP KQ1_all studies v7_Final_DP(bp goals).xlsx")
s <- read_excel("reshaped_main_with_all_RoB.xlsx")

merge <- s |>
  left_join(k, by = "Study") |>
  left_join(t, by = "Study")      # third table

merge <- merge %>%
  mutate(
    BP_goal_group_SBP = case_when(
      !is.na(`Lower (SBP)`) & `Lower (SBP)` < 120 ~ "<120",
      `Lower (SBP)` >= 120 & `Lower (SBP)` < 130 ~ "120–129",
      `Lower (SBP)` >= 130 & `Lower (SBP)` < 140 ~ "130–139",
      `Lower (SBP)` >= 140 & `Lower (SBP)` < 150 ~ "140–149",
      `Lower (SBP)` >= 150 ~ "≥150",
      TRUE ~ NA_character_
    )
  )


merged_str <- merge %>%
  mutate(`Lower (SBP)` = as.numeric(as.character(`Lower (SBP)`))) %>%
  filter(!is.na(`Lower (SBP)`))

nrow(merged_str) # suppose
colnames(merged_str)
# --- Keep descriptive variables ---

num_cols <- c("falls_low", "nTOT_falls_low", "falls_control", "nTOT_falls_control")

# force numeric conversion
merged_str[num_cols] <- lapply(merged_str[num_cols], \(x) as.numeric(as.character(x)))

descriptive_vars <- c(
  "age (mean)", "female (%)", "high CV risk (%)", "DM (%)",
  "BP_goal_group_SBP",
  "FUP_ACM", "FUP_CVM", "FUP_MCVE",
  "FUP_stroke", "FUP_kidney", "FUP_syncope",
  "FUP_ortho", "FUP_falls",
  "FUP_qol_phy", "FUP_qol_ment",
  "FUP_qol_EQ5D", "FUP_qol_EQVAS"
)
meta_fal <- merged_str%>%
  select(Study, all_of(num_cols), all_of(descriptive_vars))


#Remove rows where any event column is NA after conversion
meta_fal <- meta_fal%>%
  filter(complete.cases(across(all_of(num_cols))))
nrow(meta_fal)

view(meta_fal)
colnames(meta_fal)

# 2. Convert to numeric first
meta_fal[num_cols] <- lapply(meta_fal[num_cols], function(x) as.numeric(as.character(x)))

# 4. Remove rows with any NA in numeric columns
meta_fal <- meta_fal %>%
  filter(complete.cases(across(all_of(num_cols))))

length(meta_fal$BP_goal_group_SBP)

# 6. Check lengths

table(is.na(meta_fal))  # should all be FALSE

meta_fl <- meta_fal %>%
  # Force numeric for all meta-analysis variables
  mutate(across(all_of(num_cols), ~as.numeric(as.character(.)))) %>%
  # Ensure subgroup variable is a clean character string
  mutate(BP_goal_group_SBP = trimws(as.character(BP_goal_group_SBP))) %>%
  # Keep only rows where ALL required variables are non-NA
  filter(complete.cases(across(c(all_of(num_cols), "BP_goal_group_SBP")))) 

meta_fl <- meta_fl %>%
  mutate(across(all_of(num_cols), ~as.numeric(as.character(.)))) %>%
  mutate(BP_goal_group_SBP = trimws(as.character(BP_goal_group_SBP))) %>%
  filter(complete.cases(across(c(all_of(num_cols), "BP_goal_group_SBP")))) 

# arrange studies in the order of bp goal
meta_fl <- meta_fl|>
  mutate(
    BP_goal_group_SBP = factor(
      BP_goal_group_SBP,
      levels = c("<120", "120–129", "130–139", "140–149", "≥150")
    )
  ) |>
  arrange(BP_goal_group_SBP)

view(meta_fl)


# Ensure subgroup variable is quoted correctly
meta_falls <- metabin(
  event.e = falls_low,
  n.e = nTOT_falls_low,
  event.c = falls_control,
  n.c = nTOT_falls_control,
  studlab = Study,
  data = meta_fl,
  sm = "RR",
  method = "Inverse",
  common = FALSE,
  random = TRUE,
  subgroup = meta_fl$BP_goal_group_SBP,
  method.tau = "REML",
  incr = "TACC"
)


forest(
  meta_falls,
  print.byvar = TRUE,
  text.random = "Overall (Random effects)",
  prediction = TRUE,
  print.I2 = TRUE,
  
  smlab = "Risk Ratio (95% CI)",
  xlab = "Risk Ratio"
)

#Add descriptive variables to meta object 
meta_falls$`age (mean)`       <- meta_falls$`age (mean)`
meta_falls$`female (%)`       <- meta_falls$`female (%)`
meta_falls$`high CV risk (%)` <- meta_falls$`high CV risk (%)`
meta_falls$`DM (%)`           <- meta_falls$`DM (%)` 
meta_falls$"FUP_kidney"        <- meta_falls$"FUP_falls"

# Forest plot in pdf
pdf("forest_metaACM_rr.pdf", width = 16, height = 7)

forest(
  meta_falls,
  label.e = "Lower BP goals",
  label.c = "Higher BP goals",
  
  leftcols = c("studlab",
               "event.e", "n.e", "event.c", "n.c",
               "age (mean)", "female (%)", "high CV risk (%)",
               "DM (%)", "FUP_falls"),
  leftlabs = c("Study",
               "Events", "Total", "Events", "Total",
               "Age (mean)", "Female (%)", "High CV risk (%)",
               "DM (%)", "FU (months)"),
  
  comb.fixed = FALSE,
  comb.random = TRUE,
  print.study.ci = TRUE,
  showweights = TRUE,
  digits = 2,
  colgap.left = "7mm",
  fontsize = 10,
  plotwidth = "9cm",
  xlim = c(0.1,10),
  pooled.events = TRUE,
  print.I2.ci = TRUE,
  print.tau2 = TRUE,
  overall.hetstat = TRUE,
  test.overall = TRUE
)

# Title
grid.text(
  "Analysis of Fall Events by Systolic BP Goal",
  x = unit(0.5, "npc"),
  y = unit(0.97, "npc"),
  gp = gpar(fontsize = 13, fontface = "bold")
)
dev.off()