
k <- read_excel("follow up KQ1.xlsx")


t<- read_excel("ACP KQ1_all studies v7_Final_DP(bp goals).xlsx")
s <- read_excel("reshaped_main_with_all_RoB.xlsx")

merge <- s |>
  left_join(k, by = "Study") |>
  left_join(t, by = "Study")      # third table

merge <- merge %>%
  mutate(
    BP_goal_group_SBP = case_when(
      !is.na(`Lower (SBP)`) & `Lower (SBP)` < 120 ~ "<120",
      `Lower (SBP)` >= 120 & `Lower (SBP)` < 130 ~ "120–129",
      `Lower (SBP)` >= 130 & `Lower (SBP)` < 140 ~ "130–139",
      `Lower (SBP)` >= 140 & `Lower (SBP)` < 150 ~ "140–149",
      `Lower (SBP)` >= 150 ~ "≥150",
      TRUE ~ NA_character_
    )
  )


merged_str <- merge %>%
  mutate(`Lower (SBP)` = as.numeric(as.character(`Lower (SBP)`))) %>%
  filter(!is.na(`Lower (SBP)`))

nrow(merged_str) # suppose
colnames(merged_str)
# --- Keep descriptive variables ---

num_cols <- c("kidney_low", "nTOT_kidney_low", "kidney_control", "nTOT_kidney_control")

# force numeric conversion
merged_str[num_cols] <- lapply(merged_str[num_cols], \(x) as.numeric(as.character(x)))

descriptive_vars <- c(
  "age (mean)", "female (%)", "high CV risk (%)", "DM (%)",
  "BP_goal_group_SBP",
  "FUP_ACM", "FUP_CVM", "FUP_MCVE",
  "FUP_stroke", "FUP_kidney", "FUP_syncope",
  "FUP_ortho", "FUP_falls",
  "FUP_qol_phy", "FUP_qol_ment",
  "FUP_qol_EQ5D", "FUP_qol_EQVAS"
)
meta_kd <- merged_str%>%
  select(Study, all_of(num_cols), all_of(descriptive_vars))


#Remove rows where any event column is NA after conversion
meta_kd <- meta_kd%>%
  filter(complete.cases(across(all_of(num_cols))))
nrow(meta_kd)

view(meta_kd)
colnames(meta_kd)

# 2. Convert to numeric first
meta_kd[num_cols] <- lapply(meta_kd[num_cols], function(x) as.numeric(as.character(x)))

# 4. Remove rows with any NA in numeric columns
meta_kx <- meta_kd %>%
  filter(complete.cases(across(all_of(num_cols))))

length(meta_kx$kidney_low)

# 6. Check lengths

length(meta_kx$BP_goal_group_SBP)

table(is.na(meta_kx))  # should all be FALSE

meta_kx <- meta_kx %>%
  # Force numeric for all meta-analysis variables
  mutate(across(all_of(num_cols), ~as.numeric(as.character(.)))) %>%
  # Ensure subgroup variable is a clean character string
  mutate(BP_goal_group_SBP = trimws(as.character(BP_goal_group_SBP))) %>%
  # Keep only rows where ALL required variables are non-NA
  filter(complete.cases(across(c(all_of(num_cols), "BP_goal_group_SBP")))) 

meta_kdy <- meta_kx %>%
  mutate(across(all_of(num_cols), ~as.numeric(as.character(.)))) %>%
  mutate(BP_goal_group_SBP = trimws(as.character(BP_goal_group_SBP))) %>%
  filter(complete.cases(across(c(all_of(num_cols), "BP_goal_group_SBP")))) 

length(meta_kdy$kidney_low)

# arrange studies in the order of bp goal
meta_kdy <- meta_kdy|>
  mutate(
    BP_goal_group_SBP = factor(
      BP_goal_group_SBP,
      levels = c("<120", "120–129", "130–139", "140–149", "≥150")
    )
  ) |>
  arrange(BP_goal_group_SBP)


view(meta_kdy)


# Ensure subgroup variable is quoted correctly
meta_kdp <- metabin(
  event.e = kidney_low,
  n.e = nTOT_kidney_low,
  event.c = kidney_control,
  n.c = nTOT_kidney_control,
  studlab = Study,
  data = meta_kdy,
  sm = "RR",
  method = "Inverse",
  common = FALSE,
  random = TRUE,
  subgroup = meta_kdy$BP_goal_group_SBP,
  method.tau = "REML",
  incr = "TACC"
)


forest(
  meta_kdp,
  print.byvar = TRUE,
  text.random = "Overall (Random effects)",
  prediction = TRUE,
  print.I2 = TRUE,
  
  smlab = "Risk Ratio (95% CI)",
  xlab = "Risk Ratio"
)

#Add descriptive variables to meta object 
meta_kdp$`age (mean)`       <- meta_kdp$`age (mean)`
meta_kdp$`female (%)`       <- meta_kdp$`female (%)`
meta_kdp$`high CV risk (%)` <- meta_kdp$`high CV risk (%)`
meta_kdp$`DM (%)`           <- meta_kdp$`DM (%)` 
meta_kdp$"FUP_kidney"        <- meta_kdp$"FUP_kidney"

# Forest plot in pdf
pdf("forest_metaACM_rr.pdf", width = 16, height = 7)

forest(
  meta_kdp,
  label.e = "Lower BP goals",
  label.c = "Higher BP goals",
  
  leftcols = c("studlab",
               "event.e", "n.e", "event.c", "n.c",
               "age (mean)", "female (%)", "high CV risk (%)",
               "DM (%)", "FUP_kidney"),
  leftlabs = c("Study",
               "Events", "Total", "Events", "Total",
               "Age (mean)", "Female (%)", "High CV risk (%)",
               "DM (%)", "FU (months)"),
  
  comb.fixed = FALSE,
  comb.random = TRUE,
  print.study.ci = TRUE,
  showweights = TRUE,
  digits = 2,
  colgap.left = "7mm",
  fontsize = 10,
  plotwidth = "9cm",
  xlim = c(0.1,10),
  pooled.events = TRUE,
  print.I2.ci = TRUE,
  print.tau2 = TRUE,
  overall.hetstat = TRUE,
  test.overall = TRUE
)

# Title
grid.text(
  "Analysis of Loss of Kidney Function Events by Systolic BP Goal",
  x = unit(0.5, "npc"),
  y = unit(0.95, "npc"),
  gp = gpar(fontsize = 13, fontface = "bold")
)
dev.off()

