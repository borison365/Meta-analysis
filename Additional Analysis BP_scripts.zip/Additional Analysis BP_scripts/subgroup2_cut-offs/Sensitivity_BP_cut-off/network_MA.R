install.packages(c("netmeta", "meta", "dplyr", "ggplot2"))
library(netmeta)
library(meta)
library(dplyr)
library(ggplot2)

g <- read_excel("follow up KQ1.xlsx")

s<- read_excel("reshaped_main_with_all_RoB.xlsx")

f <- read_excel("ACP KQ1_all studies v7_Final_DP(bp goals).xlsx")

merged <- s |>
  left_join(f, by = "Study") |>
  left_join(g, by = "Study")      # third table
colnames(merged)
merge_data <- merged
merge_data <- merge_data %>%
  mutate(
    Comparator = case_when(
      !is.na(`Higher (SBP)`) & `Higher (SBP)` > 120 ~ "Comp.>120 SBP goal",
      `Higher (SBP)` >= 120 & `Higher (SBP)` < 130 ~ "Comp.120–129 SBP goal",
      `Higher (SBP)` >= 130 & `Higher (SBP)` < 140 ~ "Comp.130–139 SBP goal",
      `Higher (SBP)` >= 140 & `Higher (SBP)` < 150 ~ "Comp.140–149 SBP goal",
      TRUE ~ NA_character_
    ),
    Intervention = case_when(
      !is.na(`Lower (SBP)`) & `Lower (SBP)` < 120 ~ "<120",
      `Lower (SBP)` >= 120 & `Lower (SBP)` < 130 ~ "120–129",
      `Lower (SBP)` >= 130 & `Lower (SBP)` < 140 ~ "130–139",
      `Lower (SBP)` >= 140 & `Lower (SBP)` < 150 ~ "140–149",
      `Lower (SBP)` >= 150 ~ "≥150",
      TRUE ~ NA_character_
    )
  )
colnames(merge_data)

merge_data <- merge_data %>% 
  mutate(
    event_Interv = ACM_low,
    n_Interv = nTOT_low,
    event_Comp = ACM_control,
    n_Comp = nTOT_control
    
  )
  

# convert valuse to numeric 

num_cols <- c("n_Interv", "event_Comp", "event_Interv", "n_Comp")

# force numeric conversion
merge_data[num_cols] <- lapply(merge_data[num_cols], \(x) as.numeric(as.character(x)))

descriptive_vars <- c(
  "age (mean)", "female (%)", "high CV risk (%)", "DM (%)",
  "Comparator",  "Intervention", "n_Interv",  "event_Comp", "n_Comp", "event_Interv",
  "FUP_ACM", "FUP_CVM", "FUP_MCVE",
  "FUP_stroke", "FUP_kidney", "FUP_syncope",
  "FUP_ortho", "FUP_falls",
  "FUP_qol_phy", "FUP_qol_ment",
  "FUP_qol_EQ5D", "FUP_qol_EQVAS")


meta_data <- merge_data%>%
  select(Study, all_of(num_cols), all_of(descriptive_vars))


#Remove rows where any event column is NA after conversion
meta_data <- meta_data%>%
  filter(complete.cases(across(all_of(num_cols))))
nrow(meta_data$event_Interv)

# convert data to pairwise comparisons

pw <- pairwise(
  treat = list(Intervention, Comparator),
  event = list(event_Interv, event_Comp),
  n = list(n_Interv, n_Comp),
  studlab = Study,
  data = meta_data,
  sm = "RR"   # Relative Risk (can use "OR" or "RD" too)
)

  

                       
  













##############################untested script ..........
1️⃣ Install & load required packages
install.packages(c("netmeta", "meta", "dplyr", "ggplot2"))
library(netmeta)
library(meta)
library(dplyr)
library(ggplot2)

2️⃣ Prepare your dataset

Create or load your data in a wide format, where each row is a study comparison:
  
  # Example structure (replace with your actual data)
  sbp_data <- data.frame(
    Study = c("SPRINT", "ACCORD", "STEP", "JATOS", "VALISH", "HYVET"),
    Intervention = c("Int. <120 SBP goal",
                     "Int.120-129 SBP goal",
                     "Int.130-139 SBP goal",
                     "Int.140-149 SBP goal",
                     "Int. Any Lower SBP goals",
                     "Int. Any Lower SBP goals"),
    Comparator = c("Comp. higher than <120 SBP goal",
                   "Comp. higher than 120-129 SBP goal",
                   "Comp. higher than 130-139 SBP goal",
                   "Comp. higher than 140-149 SBP goal",
                   "Comp. any higher SBP goal",
                   "Comp. higher than 130-139 SBP goal"),
    event_Interv = c(243, 210, 180, 140, 90, 60),
    n_Interv = c(4678, 4733, 4200, 3800, 1800, 1600),
    event_Comp = c(319, 231, 210, 150, 100, 80),
    n_Comp = c(4683, 4729, 4255, 3850, 1800, 1600)
  )

3️⃣ Convert data to pairwise comparisons
pw <- pairwise(
  treat = list(Intervention, Comparator),
  event = list(event_Interv, event_Comp),
  n = list(n_Interv, n_Comp),
  studlab = Study,
  data = sbp_data,
  sm = "RR"   # Relative Risk (can use "OR" or "RD" too)
)

4️⃣ Run the network meta-analysis
net_sbp <- netmeta(
  TE = pw$TE,
  seTE = pw$seTE,
  treat1 = pw$treat1,
  treat2 = pw$treat2,
  studlab = pw$studlab,
  sm = "RR",
  comb.random = TRUE,
  method.tau = "REML",
  reference.group = "Comp. any higher SBP goal"   # Reference (baseline) group
)

5️⃣ Display summary and results
summary(net_sbp)


This will show:
  
  Pooled relative risks (RRs)

Between-study heterogeneity (τ², I²)

Network consistency statistics

6️⃣ Visualize the network and relative effects
# Network diagram
netgraph(net_sbp,
         thickness = "number.of.studies",
         number.of.studies = TRUE,
         plastic = FALSE,
         points = TRUE,
         cex.points = 5,
         col = "steelblue")

# League table (all pairwise RRs)
netleague(net_sbp, digits = 2)

7️⃣ Assess consistency and ranking
# Compare direct vs indirect evidence
netsplit(net_sbp)

# Treatment ranking
netrank(net_sbp)

8️⃣ (Optional) Convert relative risks to absolute risks

If your baseline risk (event rate) is known — say, 10% (100 per 1000):
  
  baseline_risk <- 0.10
abs_risks <- baseline_risk * net_sbp$TE.random
abs_risks


Or to compute absolute risk reduction per 1000 patients:
  
  ARR_per1000 <- 1000 * baseline_risk * (1 - net_sbp$TE.random)
ARR_per1000

9️⃣ (Optional) Integrate into Shiny app
output$network_plot <- renderPlot({
  netgraph(net_sbp,
           thickness = "number.of.studies",
           number.of.studies = TRUE,
           points = TRUE,
           cex.points = 5,
           col = "steelblue")
})

output$league_table <- renderTable({
  netleague(net_sbp, digits = 2)
})
