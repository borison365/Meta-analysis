
k <- read_excel("follow up KQ1.xlsx")
t<- read_excel("ACP KQ1_all studies v7_Final_DP(bp goals).xlsx")
s <- read_excel("reshaped_main_with_all_RoB.xlsx")

merge <- s |>
  left_join(k, by = "Study") |>
  left_join(t, by = "Study")      # third table

library(dplyr)
library(stringr)
# 1) Clean problematic characters and convert to numeric safely
merge <- merge %>%
  mutate(
    # keep original for debugging
    .raw_Lower_DBP = as.character(`Lower (DBP)`),
    # normalize common unicode dashes and whitespace, remove commas
    .clean_Lower_DBP = .raw_Lower_DBP %>%
      # replace unicode minus (U+2212) and en-dash (U+2013) with ASCII minus
      str_replace_all("\u2212", "-") %>%
      str_replace_all("\u2013", "-") %>%
      # replace any non-breaking spaces, regular multiple spaces, tabs
      str_replace_all("\u00A0", " ") %>%
      str_squish() %>%
      # remove thousands separators or stray commas
      str_replace_all(",", "") %>%
      # if parentheses like "120 (130)" keep the first number - optional
      # str_extract("^-?\\d+(?:\\.\\d+)?")  # (optional, left commented)
      as.character(),
    # final numeric coercion (suppress warnings or keep them if you want)
    `Lower (DBP)` = as.numeric(.clean_Lower_DBP)
  )

# 2) Show how many converted to NA (diagnostic)
n_total <- nrow(merge)
n_na <- sum(is.na(merge$`Lower (DBP)`))
cat(sprintf("Converted to numeric: %d / %d non-NA ( %d NAs )\n", n_total - n_na, n_total, n_na))

# 3) Show the problematic raw strings (if any) to help debug
if (n_na > 0) {
  cat("=== Examples of rows where conversion produced NA ===\n")
  print(
    merge %>%
      filter(is.na(`Lower (DBP)`)) %>%
      select(Study, .raw_Lower_DBP, .clean_Lower_DBP) %>%
      slice_head(n = 20)
  )
} else {
  cat("No conversion failures detected.\n")
}

# 4) Now create the group variable safely (use backticks and numeric comparisons).
#    Note: adjust labels/ranges as you intend. I'm preserving your original idea but
#    making the ranges continuous and non-overlapping:
merge <- merge %>%
  mutate(
    BP_goal_group_DBP = case_when(
      !is.na(`Lower (DBP)`) & `Lower (DBP)` < 70                  ~ "≤69",
      `Lower (DBP)` >= 70 & `Lower (DBP)` < 80                    ~ "70–79",
      `Lower (DBP)` >= 80 & `Lower (DBP)` < 90                    ~ "80–89",
      `Lower (DBP)` >= 90                                         ~ "90",
      TRUE                                                         ~ NA_character_
    )
  )

# 5) Quick frequency table to check groups
cat("=== BP_goal_group_DBP distribution ===\n")
print(table(merge$BP_goal_group_DBP, useNA = "ifany"))

# 6) If you want to drop the helper columns afterwards:
merge <- merge %>% select(-.raw_Lower_DBP, -.clean_Lower_DBP)

# --- Keep descriptive variables ---
num_cols <- c("ortho_low", "nTOT_ortho_low", "ortho_control", "nTOT_ortho_control")

# force numeric conversion
merge[num_cols] <- lapply(merge[num_cols], \(x) as.numeric(as.character(x)))

descriptive_vars <- c(
  "age (mean)", "female (%)", "high CV risk (%)", "DM (%)",
  "BP_goal_group_DBP",
  "FUP_ACM", "FUP_CVM", "FUP_MCVE",
  "FUP_stroke", "FUP_kidney", "FUP_syncope",
  "FUP_ortho", "FUP_falls",
  "FUP_qol_phy", "FUP_qol_ment",
  "FUP_qol_EQ5D", "FUP_qol_EQVAS"
)

view(merge$BP_goal_group_DBP)

meta_mcve <- merge%>%
  select(Study, all_of(num_cols), all_of(descriptive_vars))

view(meta_mcve)
### NB - Zero event for all DBP goals - no further analysis!!!