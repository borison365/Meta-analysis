library(grid)
library(dplyr)
library(tidyverse)
library(meta)
library(ggplot2)
g <- read_excel("follow up KQ1.xlsx")


f<- read_excel("ACP KQ1_all studies v7_Final_DP(bp goals).xlsx")
s <- read_excel("reshaped_main_with_all_RoB.xlsx")

merge <- s |>
  left_join(f, by = "Study") |>
  left_join(g, by = "Study")      # third table

merge <- merge %>%
  mutate(
    BP_goal_group_SBP = case_when(
      !is.na(`Lower (SBP)`) & `Lower (SBP)` < 120 ~ "<120",
      `Lower (SBP)` >= 120 & `Lower (SBP)` < 130 ~ "120–129",
      `Lower (SBP)` >= 130 & `Lower (SBP)` < 140 ~ "130–139",
      `Lower (SBP)` >= 140 & `Lower (SBP)` < 150 ~ "140–149",
      `Lower (SBP)` >= 150 ~ "≥150",
      TRUE ~ NA_character_
    )
  )


merged_me <- merge %>%
  mutate(`Lower (SBP)` = as.numeric(as.character(`Lower (SBP)`))) %>%
  filter(!is.na(`Lower (SBP)`))

colnames(merged_me)
# --- Keep descriptive variables ---

num_cols <- c("MCVE_low", "nTOT_low", "MCVE_control", "nTOT_control")

# force numeric conversion
merged_me[num_cols] <- lapply(merged_me[num_cols], \(x) as.numeric(as.character(x)))

descriptive_vars <- c(
  "age (mean)", "female (%)", "high CV risk (%)", "DM (%)",
  "BP_goal_group_SBP",
  "FUP_ACM", "FUP_CVM", "FUP_MCVE",
  "FUP_stroke", "FUP_kidney", "FUP_syncope",
  "FUP_ortho", "FUP_falls",
  "FUP_qol_phy", "FUP_qol_ment",
  "FUP_qol_EQ5D", "FUP_qol_EQVAS"
)
meta_macve <- merged_me%>%
  select(Study, all_of(num_cols), all_of(descriptive_vars))

view(meta_macve)
colnames(meta_macve)
# 2. Convert to numeric first
meta_macve[num_cols] <- lapply(meta_macve[num_cols], function(x) as.numeric(as.character(x)))

# 4. Remove rows with any NA in numeric columns
meta_dr <- meta_macve %>%
  filter(complete.cases(across(all_of(num_cols))))

view(meta_dr)

# 6. Check lengths
length(meta_dr$MCVE_low)
length(meta_dr$BP_goal_group_SBP)

meta_macve <- meta_dr %>%
  mutate(across(all_of(num_cols), ~as.numeric(as.character(.)))) %>%
  mutate(BP_goal_group_SBP = trimws(as.character(BP_goal_group_SBP))) %>%
  filter(complete.cases(across(c(all_of(num_cols), "BP_goal_group_SBP")))) 



# arrange studies in the order of bp goal
meta_macve <- meta_macve|>
  mutate(
    BP_goal_group_SBP = factor(
      BP_goal_group_SBP,
      levels = c("<120", "120–129", "130–139", "140–149", "≥150")
    )
  ) |>
  arrange(BP_goal_group_SBP)

view(meta_macve)


# Ensure subgroup variable is quoted correctly
meta_m <- metabin(
  event.e = MCVE_low,
  n.e = nTOT_low,
  event.c = MCVE_control,
  n.c = nTOT_control,
  studlab = Study,
  data = meta_macve,
  sm = "RR",
  method = "Inverse",
  common = FALSE,
  random = TRUE,
  subgroup = meta_macve$BP_goal_group_SBP,
  method.tau = "REML",
  incr = "TACC"
)


forest(
  meta_m,
  print.byvar = TRUE,
  text.random = "Overall (Random effects)",
  prediction = TRUE,
  print.I2 = TRUE,
  
  smlab = "Risk Ratio (95% CI)",
  xlab = "Risk Ratio"
)

#Add descriptive variables to meta object 

meta_m$`age (mean)`       <- meta_m$`age (mean)`
meta_m$`female (%)`       <- meta_m$`female (%)`
meta_m$`high CV risk (%)` <- meta_m$`high CV risk (%)`
meta_m$`DM (%)`           <- meta_m$`DM (%)` 
meta_m$"FUP_CVM"        <- meta_m$"FUP_MCVE"

# Forest plot in pdf
pdf("forest_metaACM_rr.pdf", width = 16, height = 7)

forest(
  meta_m,
  label.e = "Lower BP goals",
  label.c = "Higher BP goals",
  
  leftcols = c("studlab",
               "event.e", "n.e", "event.c", "n.c",
               "age (mean)", "female (%)", "high CV risk (%)",
               "DM (%)", "FUP_MCVE"),
  leftlabs = c("Study",
               "Events", "Total", "Events", "Total",
               "Age (mean)", "Female (%)", "High CV risk (%)",
               "DM (%)", "FU (months)"),
  
  comb.fixed = FALSE,
  comb.random = TRUE,
  print.study.ci = TRUE,
  showweights = TRUE,
  digits = 2,
  colgap.left = "7mm",
  fontsize = 10,
  plotwidth = "9cm",
  xlim = c(0.1,10),
  pooled.events = TRUE,
  print.I2.ci = TRUE,
  print.tau2 = TRUE,
  overall.hetstat = TRUE,
  test.overall = TRUE
)

# Title
grid.text(
  "Major Cardiovascular Events Sensitivity Analysis by Systolic BP Goal",
  x = unit(0.5, "npc"),
  y = unit(0.97, "npc"),
  gp = gpar(fontsize = 13, fontface = "bold")
)
dev.off()
