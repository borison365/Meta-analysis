library(readxl)
library(readr)
library(dplyr)
library(meta)
library(grid)

# --- Load data ---
f <- read_excel("follow up KQ1.xlsx")
d <- read_excel("ACP KQ1_all studies v7_Final_DP(bp goals).xlsx")
l <- read_csv("reshaped_main_with_all_RoB(Sheet1).csv")

# --- Merge datasets ---
merged <- l |>
  left_join(d, by = "Study") |>
  left_join(f, by = "Study")

# --- Define SBP goal ---
merged <- merged %>%
  mutate(
    `Lower (SBP)` = as.numeric(as.character(`Lower (SBP)`)),
    SBP_goal = case_when(
      !is.na(`Lower (SBP)`) & `Lower (SBP)` < 120 ~ "<120",
      !is.na(`Lower (SBP)`) & `Lower (SBP)` >= 120 ~ ">120",
      TRUE ~ NA_character_
    )
  )

# --- Clean numeric columns ---
num_cols <- c("ACM_low", "nTOT_low", "ACM_control", "nTOT_control")
merged[num_cols] <- lapply(merged[num_cols], \(x) as.numeric(as.character(x)))

# --- Define RoB grouping variable ---
merged <- merged %>%
  mutate(
    RoB_group = case_when(
      RoB_ACM_Overall == "Low" ~ "Low RoB",
      RoB_ACM_Overall %in% c("Some concerns", "High") ~ "Some/High RoB",
      TRUE ~ NA_character_
    )
  )

# --- Combined label for clarity ---
merged <- merged %>%
  mutate(BP_RoB_group = paste(SBP_goal, RoB_group, sep = "_"))

colnames(merged)

# --- Clean dataset ---
meta_base <- merged %>%
  filter(!is.na(SBP_goal), !is.na(RoB_group)) %>%
  filter(complete.cases(across(all_of(num_cols))))
# --- Keep descriptive variables ---

num_cols <- c("ACM_low", "nTOT_low", "ACM_control", "nTOT_control")

# force numeric conversion
meta_base[num_cols] <- lapply(meta_base[num_cols], \(x) as.numeric(as.character(x)))

descriptive_vars <- c(
  "age (mean)", "female (%)", "high CV risk (%)", "DM (%)",
  "SBP_goal", "BP_RoB_group", "RoB_group", 
  "FUP_ACM", "FUP_CVM", "FUP_MCVE",
  "FUP_stroke", "FUP_kidney", "FUP_syncope",
  "FUP_ortho", "FUP_falls",
  "FUP_qol_phy", "FUP_qol_ment",
  "FUP_qol_EQ5D", "FUP_qol_EQVAS"
)
meta_data <- meta_base%>%
  select(Study, all_of(num_cols), all_of(descriptive_vars))
View(meta_data)
