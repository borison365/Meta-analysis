
k <- read_excel("follow up KQ1.xlsx")


t<- read_excel("ACP KQ1_all studies v7_Final_DP(bp goals).xlsx")
s <- read_excel("reshaped_main_with_all_RoB.xlsx")

merge <- s |>
  left_join(k, by = "Study") |>
  left_join(t, by = "Study")      # third table

merge <- merge %>%
  mutate(
    BP_goal_group_SBP = case_when(
      !is.na(`Lower (SBP)`) & `Lower (SBP)` < 120 ~ "<120",
      `Lower (SBP)` >= 120 & `Lower (SBP)` < 130 ~ "120–129",
      `Lower (SBP)` >= 130 & `Lower (SBP)` < 140 ~ "130–139",
      `Lower (SBP)` >= 140 & `Lower (SBP)` < 150 ~ "140–149",
      `Lower (SBP)` >= 150 ~ "≥150",
      TRUE ~ NA_character_
    )
  )


merged_str <- merge %>%
  mutate(`Lower (SBP)` = as.numeric(as.character(`Lower (SBP)`))) %>%
  filter(!is.na(`Lower (SBP)`))

nrow(merged_str) # suppose
colnames(merged_str)
# --- Keep descriptive variables ---

num_cols <- c( 
              "qol_phy_low" , "nTOT_qol_phy_low", "qol_phy_low_SD", 
              "qol_ment_low" , "nTOT_qol_ment_low" , "qol_ment_low_SD" ,
              "qol_EQ5D_low",  "nTOT_qol_EQ5D_low", "qol_EQ5D_low_SD",  
              "qol_EQVAS_low", "nTOT_qol_EQVAS_low" , "qol_EQVAS_low_SD" , 
              "nTOT_qol_ment_control",  "qol_ment_control" , "qol_ment_control_SD" ,
              "qol_phy_control", "nTOT_qol_phy_control", "qol_phy_control_SD" , 
              "nTOT_qol_EQ5D_control", "qol_EQ5D_control" ,  "qol_EQ5D_control_SD",
              "qol_EQVAS_control" , "nTOT_qol_EQVAS_control", "qol_EQVAS_control_SD" 
              )

# force numeric conversion
merged_str[num_cols] <- lapply(merged_str[num_cols], \(x) as.numeric(as.character(x)))

descriptive_vars <- c(
  "age (mean)", "female (%)", "high CV risk (%)", "DM (%)",
  "BP_goal_group_SBP",
  "FUP_ACM", "FUP_CVM", "FUP_MCVE",
  "FUP_stroke", "FUP_kidney", "FUP_syncope",
  "FUP_ortho", "FUP_falls",
  "FUP_qol_phy", "FUP_qol_ment",
  "FUP_qol_EQ5D", "FUP_qol_EQVAS"
)
meta_qol <- merged_str%>%
  select(Study, all_of(num_cols), all_of(descriptive_vars))

view(meta_qol)

colnames(meta_qol)

# 2. Convert to numeric first
meta_qol[num_cols] <- lapply(meta_qol[num_cols], function(x) as.numeric(as.character(x)))

# 4. Re

length(meta_qol$BP_goal_group_SBP)

view(meta_qol)
# 6. Check lengths

table(is.na(meta_qol))  # should all be FALSE

meta_qol_phy <- meta_qol %>%
  filter(Study=="SPRINT, 2015")

view(meta_qol_phy)  

#Meta
meta_qol_phy <- metacont(
  n.e = nTOT_qol_phy_low, mean.e = qol_phy_low, sd.e = qol_phy_low_SD,   # sample size, mean, SD in experimental group
  n.c = nTOT_qol_phy_control, mean.c = qol_phy_control, sd.c = qol_phy_control_SD ,   # sample size, mean, SD in control group
  data = meta_qol_phy,                
  studlab = Study,     
  sm = "SMD",      
  method.smd = "Hedges", 
  common = FALSE,  
  random = TRUE, 
)

#Add descriptive variables to meta object 
meta_qol_phy$`age (mean)`       <- meta_qol_phy$`age (mean)`
meta_qol_phy$`female (%)`       <- meta_qol_phy$`female (%)`
meta_qol_phy$`high CV risk (%)` <- meta_qol_phy$`high CV risk (%)`
meta_qol_phy$`DM (%)`           <- meta_qol_phy$`DM (%)`
meta_qol_phy$"FUP_qol_phy"   <-meta_qol_phy$"FUP_qol_phy"

###################################################################

## *** NEW: drop rows that have no data on any of the num_cols ***
meta_qol[num_cols] <- lapply(
  meta_qol[num_cols],
  \(x) x |>
    gsub("\u2212", "-", x = _) |>    # replace unicode minus with ASCII minus
    as.numeric()
)



forest(
  meta_qol_phy,
  label.e = "Lower BP goals",
  label.c = "Higher BP goals",
  
  # Left columns
  leftcols = c("studlab",
               "n.e", "mean.e", "sd.e",
               "n.c", "mean.c", "sd.c",
               "age (mean)", "female (%)", "high CV risk (%)",
               "DM (%)", "FUP_qol_phy"),
  leftlabs = c("Study",
               "Total", "Mean", "SD",
               "Total", "Mean", "SD",
               "Age (mean)", "Female (%)", "High CV risk (%)",
               "DM (%)", "FU (months)"),
  smlab = "Standardized mean difference",
  comb.fixed = FALSE,     
  comb.random = TRUE,       
  print.study.ci = TRUE,       
  showweights = TRUE,          
  digits = 2,                  # decimals for RR and CI
  # Formatting
  colgap.left = "4mm",
  fontsize = 10,
  plotwidth = "9cm",  
  xlim = c(-1, 1),
  pooled.events = TRUE,
  print.I2.ci = TRUE,
  print.tau2 = TRUE,
  overall.hetstat = TRUE,
  test.overall = TRUE
)

# Title
grid.text(
  "Outcome: quality of life – physical domain",
  x = unit(0.5, "npc"),
  y = unit(0.97, "npc"),
  gp = gpar(fontsize = 14, fontface = "bold")
)
dev.off()

