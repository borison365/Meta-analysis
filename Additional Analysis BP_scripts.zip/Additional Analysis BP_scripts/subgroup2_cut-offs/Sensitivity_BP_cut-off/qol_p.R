
##############################################################################
#################### Task 1 - SBP goal <120 vs ≥ 120 ##################################
##############################################################################

# load our datasets

f <- read_excel("follow up KQ1_updated.xlsx")
d<- read_excel("ACP KQ1_all studies v7_Final_DP(bp goals).xlsx")
l <- read_csv("reshaped_main_with_all_RoB(Sheet1).csv")

#  Merge them 
merged <- l |>
  left_join(d, by = "Study") |>
  left_join(f, by = "Study")      # third table

merged <- merged %>%
  mutate(
    SBP_goal = case_when(
      !is.na(`Lower (SBP)`) & `Lower (SBP)` < 120 ~ "<120",
      `Lower (SBP)` >= 120 ~ ">=120",
      TRUE ~ NA_character_
    )
  )


merged_cl <- merged %>%
  mutate(`Lower (SBP)` = as.numeric(as.character(`Lower (SBP)`))) %>%
  filter(!is.na(`Lower (SBP)`))

nrow(merged_cl) # suppose to return 21 rows
colnames(merged_cl)

# --- Keep descriptive variables ---

num_cols <- c("qol_phy_low", "nTOT_qol_phy_low", "qol_phy_control", "nTOT_qol_phy_control")

# force numeric conversion
merged_cl[num_cols] <- lapply(merged_cl[num_cols], \(x) as.numeric(as.character(x)))

descriptive_vars <- c(
  "age (mean)", "female (%)", "high CV risk (%)", "DM (%)",
  "SBP_goal",
  "FUP_ACM", "FUP_CVM", "FUP_MCVE",
  "FUP_stroke", "FUP_kidney", "FUP_syncope",
  "FUP_ortho", "FUP_falls",
  "FUP_qol_phy", "FUP_qol_ment",
  "FUP_qol_EQ5D", "FUP_qol_EQVAS"
)

meta_data <- merged_cl%>%
  select(Study, all_of(num_cols), all_of(descriptive_vars))

#Remove rows where any event column is NA after conversion
meta_dw <- meta_data %>%
  filter(complete.cases(across(all_of(num_cols))))
nrow(meta_dw)

# 2. Convert to numeric first
meta_dw[num_cols] <- lapply(meta_dw[num_cols], function(x) as.numeric(as.character(x)))

View(meta_dw)

# 4. Remove rows with any NA in numeric columns
meta_df <- meta_dw %>%
  filter(complete.cases(across(all_of(num_cols))))


# Recode and order SBP goal

meta_df <- meta_df %>%
  mutate(
    SBP_goal = factor(trimws(SBP_goal), levels = c("<120", ">=120"))
  ) %>%
  arrange(SBP_goal)

# Check order
table(meta_df$SBP_goal)

View(meta_df)


meta_clin <- meta_df %>%
  # Force numeric for all meta-analysis variables
  mutate(across(all_of(num_cols), ~as.numeric(as.character(.)))) %>%
  # Ensure subgroup variable is a clean character string
  mutate(SBP_goal = trimws(as.character(SBP_goal))) %>%
  # Keep only rows where ALL required variables are non-NA
  filter(complete.cases(across(c(all_of(num_cols), "SBP_goal")))) 

meta_cln <- meta_clin %>%
  mutate(across(all_of(num_cols), ~as.numeric(as.character(.)))) %>%
  mutate(SBP_goal = trimws(as.character(SBP_goal))) %>%
  filter(complete.cases(across(c(all_of(num_cols), "SBP_goal")))) 

# View if the arrangement worked
View(meta_cln)

# QoL physical domain
#subset the data to studies with non-missing values
data_clean <- subset(data, !is.na(qol_phy_low) & !is.na(qol_phy_control))

#Meta
meta_qol_phy <- metacont(
  n.e = nTOT_qol_phy_low, mean.e = qol_phy_low, sd.e = qol_phy_low_SD,   # sample size, mean, SD in experimental group
  n.c = nTOT_qol_phy_control, mean.c = qol_phy_control, sd.c = qol_phy_control_SD ,   # sample size, mean, SD in control group
  data = data_clean,                
  studlab = Study,     
  sm = "SMD",      
  method.smd = "Hedges", 
  common = FALSE,  
  random = TRUE, 
)
print(meta_qol_phy)
#Add descriptive variables to meta object 
meta_qol_phy$`age (mean)`       <- data_clean$`age (mean)`
meta_qol_phy$`female (%)`       <- data_clean$`female (%)`
meta_qol_phy$`high CV risk (%)` <- data_clean$`high CV risk (%)`
meta_qol_phy$`DM (%)`           <- data_clean$`DM (%)`
meta_qol_phy$`lower SBP goal`   <- data_clean$`lower SBP goal`
meta_qol_phy$`higher SBP goal`  <- data_clean$`higher SBP goal`

# Forest plot in pdf
pdf("forest_meta_qol_phy_rr.pdf", width = 17, height = 2.5)

forest(
  meta_qol_phy,
  label.e = "Lower BP goals",
  label.c = "Higher BP goals",
  
  # Left columns
  leftcols = c("studlab",
               "n.e", "mean.e", "sd.e",
               "n.c", "mean.c", "sd.c",
               "age (mean)", "female (%)", "high CV risk (%)",
               "DM (%)", "lower SBP goal", "higher SBP goal"),
  leftlabs = c("Study",
               "Total", "Mean", "SD",
               "Total", "Mean", "SD",
               "Age (mean)", "Female (%)", "High CV risk (%)",
               "DM (%)", "Lower SBP goal", "Higher SBP goal"),
  smlab = "Standardized mean difference",
  comb.fixed = FALSE,     
  comb.random = TRUE,       
  print.study.ci = TRUE,       
  showweights = TRUE,          
  digits = 2,                  # decimals for RR and CI
  # Formatting
  colgap.left = "4mm",
  fontsize = 10,
  plotwidth = "9cm",  
  xlim = c(-1, 1),
  pooled.events = TRUE,
  print.I2.ci = TRUE,
  print.tau2 = TRUE,
  overall.hetstat = TRUE,
  test.overall = TRUE
)

# Title
grid.text(
  "Outcome: quality of life – physical domain",
  x = unit(0.5, "npc"),
  y = unit(0.97, "npc"),
  gp = gpar(fontsize = 14, fontface = "bold")
)
dev.off()
