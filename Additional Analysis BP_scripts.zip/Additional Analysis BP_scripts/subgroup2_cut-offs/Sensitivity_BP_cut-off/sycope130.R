
##############################################################################
#################### Task 1 - SBP goal <130 vs ≥ 130 ##################################
##############################################################################

# load our datasets

f <- read_excel("follow up KQ1_updated.xlsx")
d<- read_excel("ACP KQ1_all studies v7_Final_DP(bp goals).xlsx")
l <- read_csv("reshaped_main_with_all_RoB(Sheet1).csv")

#  Merge them 
merged <- l |>
  left_join(d, by = "Study") |>
  left_join(f, by = "Study")      # third table

merged <- merged %>%
  mutate(
    SBP_goal = case_when(
      !is.na(`Lower (SBP)`) & `Lower (SBP)` < 130 ~ "<130",
      `Lower (SBP)` >= 130 ~ ">=130",
      TRUE ~ NA_character_
    )
  )


merged_cl <- merged %>%
  mutate(`Lower (SBP)` = as.numeric(as.character(`Lower (SBP)`))) %>%
  filter(!is.na(`Lower (SBP)`))

nrow(merged_cl) # suppose to return 21 rows
colnames(merged_cl)

# --- Keep descriptive variables ---

num_cols <- c("syncope_low", "nTOT_low", "syncope_control", "nTOT_control")

# force numeric conversion
merged_cl[num_cols] <- lapply(merged_cl[num_cols], \(x) as.numeric(as.character(x)))

descriptive_vars <- c(
  "age (mean)", "female (%)", "high CV risk (%)", "DM (%)",
  "SBP_goal",
  "FUP_ACM", "FUP_CVM", "FUP_MCVE",
  "FUP_stroke", "FUP_kidney", "FUP_syncope",
  "FUP_ortho", "FUP_falls",
  "FUP_qol_phy", "FUP_qol_ment",
  "FUP_qol_EQ5D", "FUP_qol_EQVAS"
)

meta_data <- merged_cl%>%
  select(Study, all_of(num_cols), all_of(descriptive_vars))

#Remove rows where any event column is NA after conversion
meta_dw <- meta_data %>%
  filter(complete.cases(across(all_of(num_cols))))
nrow(meta_dw)

# 2. Convert to numeric first
meta_dw[num_cols] <- lapply(meta_dw[num_cols], function(x) as.numeric(as.character(x)))

View(meta_dw)

# 4. Remove rows with any NA in numeric columns
meta_df <- meta_dw %>%
  filter(complete.cases(across(all_of(num_cols))))


# Recode and order SBP goal

meta_df <- meta_df %>%
  mutate(
    SBP_goal = factor(trimws(SBP_goal), levels = c("<130", ">=130"))
  ) %>%
  arrange(SBP_goal)

# Check order
table(meta_df$SBP_goal)

View(meta_df)


meta_clin <- meta_df %>%
  # Force numeric for all meta-analysis variables
  mutate(across(all_of(num_cols), ~as.numeric(as.character(.)))) %>%
  # Ensure subgroup variable is a clean character string
  mutate(SBP_goal = trimws(as.character(SBP_goal))) %>%
  # Keep only rows where ALL required variables are non-NA
  filter(complete.cases(across(c(all_of(num_cols), "SBP_goal")))) 

meta_cln <- meta_clin %>%
  mutate(across(all_of(num_cols), ~as.numeric(as.character(.)))) %>%
  mutate(SBP_goal = trimws(as.character(SBP_goal))) %>%
  filter(complete.cases(across(c(all_of(num_cols), "SBP_goal")))) 

# View if the arrangement worked
View(meta_cln)

# Ensure subgroup variable is quoted correctly
meta_r <- metabin(
  event.e = syncope_low,       ## replace the outcome of interest... syncope
  n.e = nTOT_low,
  event.c = syncope_control,
  n.c = nTOT_control,
  studlab = Study,
  data = meta_cln,
  sm = "RR",
  method = "Inverse",
  common = FALSE,
  random = TRUE,
  subgroup = meta_cln$SBP_goal,  # Same SBP group per outcome
  method.tau = "REML",
  incr = "TACC"
)


forest(
  meta_r,
  print.byvar = TRUE,
  text.random = "Overall (Random effects)",
  prediction = TRUE,
  print.I2 = TRUE,
  
  smlab = "Risk Ratio (95% CI)",
  xlab = "Risk Ratio"
)

#Add descriptive variables to meta object 

meta_r$`age (mean)`       <- meta_cln$`age (mean)`
meta_r$`female (%)`       <- meta_cln$`female (%)`
meta_r$`high CV risk (%)` <- meta_cln$`high CV risk (%)`
meta_r$`DM (%)`           <- meta_cln$`DM (%)` 
meta_r$"FUP_syncope"        <- meta_cln$"FUP_syncope"          # adjust the corresponding FU column syncope

# Forest plot in pdf
pdf("forest_metaACM_rr.pdf", width = 16, height = 7)

forest(
  meta_r,
  label.e = "Lower BP goals",
  label.c = "Higher BP goals",
  
  leftcols = c("studlab",
               "event.e", "n.e", "event.c", "n.c",
               "age (mean)", "female (%)", "high CV risk (%)",
               "DM (%)", "FUP_syncope"),                   # use the proper outcome column name syncope
  leftlabs = c("Study",
               "Events", "Total", "Events", "Total",
               "Age (mean)", "Female (%)", "High CV risk (%)",
               "DM (%)", "FU (months)"),
  
  comb.fixed = FALSE,
  comb.random = TRUE,
  print.study.ci = TRUE,
  showweights = TRUE,
  digits = 2,
  colgap.left = "6mm",
  fontsize = 10,
  plotwidth = "9cm",
  xlim = c(0.1,10),
  pooled.events = TRUE,
  print.I2.ci = TRUE,
  print.tau2 = TRUE,
  overall.hetstat = TRUE,
  prediction = TRUE,
  test.overall = TRUE
)

# Title
grid.text(
  "Analysis of Studies with Syncope Events by SBP Cut-off <130 vs ≥130",
  x = unit(0.5, "npc"),
  y = unit(0.97, "npc"),
  gp = gpar(fontsize = 13, fontface = "bold")
)
dev.off()
