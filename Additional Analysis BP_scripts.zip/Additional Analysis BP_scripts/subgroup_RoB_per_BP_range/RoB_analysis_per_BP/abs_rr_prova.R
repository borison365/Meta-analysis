
#
# Run the app with: runApp("path/to/this/app.R") or open in RStudio and click Run App.

library(shiny)
library(meta)
library(ggplot2)
library(dplyr)


# ---------------------------
# Helper functions
# ---------------------------

TU_from_RD_piecewise <- function(RD, t1, t2, t3) {
  # Map an RD magnitude (per 1000) to threshold-units piecewise scale
  w1 <- t1
  w2 <- t2 - t1
  w3 <- t3 - t2
  rd <- pmax(0, RD)
  ifelse(rd < t1, rd / w1,
         ifelse(rd < t2, 1 + (rd - t1) / w2,
                ifelse(rd < t3, 2 + (rd - t2) / w3,
                       3 + (rd - t3) / w3)))
}

signed_TU_dich_undesirable <- function(rd_per1000, t1, t2, t3) {
  # For outcomes where fewer events = benefit, positive RD (fewer events) => negative TU
  if (!is.finite(rd_per1000)) return(NA_real_)
  if (abs(rd_per1000) < 1e-12) return(0)
  mag_TU <- TU_from_RD_piecewise(abs(rd_per1000), t1, t2, t3)
  is_benefit <- rd_per1000 > 0
  ifelse(is_benefit, -mag_TU, +mag_TU)
}

# ---------------------------
# Robust compute function
# ---------------------------
compute_TU_df_from_meta <- function(meta_result,
                                    baseline_per1000,
                                    t1, t2, t3,
                                    data_in = NULL,
                                    study_col = "Study",
                                    year_col_candidates = c("Year...4", "Year")) {
  # Validate
  if (is.null(meta_result)) return(NULL)
  if (missing(baseline_per1000)) stop("baseline_per1000 required")
  
  # Build per-study meta table directly from meta_result (preserves TE/seTE association)
  df_meta <- data.frame(
    Study = as.character(meta_result$studlab),
    TE = as.numeric(meta_result$TE),
    seTE = as.numeric(meta_result$seTE),
    stringsAsFactors = FALSE
  )
  
  # If data_in not supplied, try to use global data_clean if present
  if (is.null(data_in) && exists("data_clean", envir = .GlobalEnv)) {
    data_in <- get("data_clean", envir = .GlobalEnv)
  }
  
  # Determine which year column we have (if any)
  year_col <- NULL
  if (!is.null(data_in) && is.data.frame(data_in)) {
    for (cand in year_col_candidates) {
      if (cand %in% colnames(data_in)) {
        year_col <- cand
        break
      }
    }
  }
  
  # Left join df_meta with data_in (if available) to bring Year for ordering without breaking TE mapping
  if (!is.null(data_in) && study_col %in% colnames(data_in)) {
    # select only necessary cols to avoid accidental overwrites
    if (!is.null(year_col)) {
      df_join <- data_in %>% select(all_of(c(study_col, year_col))) %>% distinct()
    } else {
      df_join <- data_in %>% select(all_of(study_col)) %>% distinct()
    }
    colnames(df_join)[colnames(df_join) == study_col] <- "Study"
    df_merged <- left_join(df_meta, df_join, by = "Study")
    # Warn if any studies from meta are not found in data_in$Study
    missing_idx <- which(is.na(df_merged[[ifelse(is.null(year_col), "Study", year_col)]] & !(df_merged$Study %in% df_join$Study)))
    # The above attempt to detect missing year may not be robust; instead explicitly detect membership
    not_found <- setdiff(df_meta$Study, df_join$Study)
    if (length(not_found) > 0) {
      warning("The following studies in meta_result$studlab were not found in data_in$", study_col, ": ",
              paste(head(not_found, 20), collapse = ", "), if (length(not_found) > 20) " ...")
    }
  } else {
    # No data_in: keep df_meta as-is (will use meta order)
    df_merged <- df_meta
  }
  
  # Order studies: if year_col present in df_merged, order by year then Study; else keep the meta order
  if (!is.null(year_col) && year_col %in% colnames(df_merged)) {
    # Place NA years last; order ascending (oldest first)
    df_ordered <- df_merged %>% arrange(is.na(.data[[year_col]]), .data[[year_col]], Study)
  } else {
    df_ordered <- df_merged
  }
  
  # TE and seTE vectors in the correct order corresponding to ordered Study vector
  TE_vec <- df_ordered$TE
  seTE_vec <- df_ordered$seTE
  ordered_labels <- df_ordered$Study
  
  # Per-study RRs and 95% CI (TE = log RR)
  RR <- exp(TE_vec)
  RR_l <- exp(TE_vec - 1.96 * seTE_vec)
  RR_u <- exp(TE_vec + 1.96 * seTE_vec)
  
  # Transform RR -> RD (per 1000)
  # Important: RD = baseline * (1 - RR). Because RD decreases when RR increases, CI endpoints invert:
  # lower RD bound corresponds to upper RR bound; upper RD bound corresponds to lower RR bound.
  RD <- baseline_per1000 * (1 - RR)
  RD_l <- baseline_per1000 * (1 - RR_u)  # lower RD from upper RR
  RD_u <- baseline_per1000 * (1 - RR_l)  # upper RD from lower RR
  
  # Pooled (random effects) extraction (TE.random etc on log scale)
  pool_TE <- as.numeric(meta_result$TE.random)
  pool_l  <- as.numeric(meta_result$lower.random)
  pool_u  <- as.numeric(meta_result$upper.random)
  
  RR_pool   <- exp(pool_TE)
  RR_pool_l <- exp(pool_l)
  RR_pool_u <- exp(pool_u)
  
  RD_pool   <- baseline_per1000 * (1 - RR_pool)
  RD_pool_l <- baseline_per1000 * (1 - RR_pool_u)  # swap
  RD_pool_u <- baseline_per1000 * (1 - RR_pool_l)  # swap
  
  # Prediction interval transformation if present
  if (!is.null(meta_result$lower.predict) && !is.null(meta_result$upper.predict)) {
    RR_pil <- exp(meta_result$lower.predict)
    RR_piu <- exp(meta_result$upper.predict)
    RD_pil <- baseline_per1000 * (1 - RR_pil)
    RD_piu <- baseline_per1000 * (1 - RR_piu)
  } else {
    RD_pil <- RD_piu <- NA_real_
  }
  
  # Convert RD -> TU (signed)
  TU_study <- vapply(RD, function(x) signed_TU_dich_undesirable(x, t1, t2, t3), numeric(1))
  TU_l_st  <- vapply(RD_l, function(x) signed_TU_dich_undesirable(x, t1, t2, t3), numeric(1))
  TU_u_st  <- vapply(RD_u, function(x) signed_TU_dich_undesirable(x, t1, t2, t3), numeric(1))
  
  TU_pool  <- signed_TU_dich_undesirable(RD_pool, t1, t2, t3)
  TU_pool_l <- signed_TU_dich_undesirable(RD_pool_l, t1, t2, t3)
  TU_pool_u <- signed_TU_dich_undesirable(RD_pool_u, t1, t2, t3)
  TU_pil <- if (is.finite(RD_pil)) signed_TU_dich_undesirable(RD_pil, t1, t2, t3) else NA_real_
  TU_piu <- if (is.finite(RD_piu)) signed_TU_dich_undesirable(RD_piu, t1, t2, t3) else NA_real_
  
  tudf_studies <- data.frame(
    label = ordered_labels,
    type  = "study",
    TU    = TU_study,
    lci   = pmin(TU_l_st, TU_u_st, na.rm = TRUE),
    uci   = pmax(TU_l_st, TU_u_st, na.rm = TRUE),
    pil   = NA_real_,
    piu   = NA_real_,
    stringsAsFactors = FALSE
  )
  
  tudf_pool <- data.frame(
    label = "Pooled",
    type  = "pooled",
    TU    = TU_pool,
    lci   = min(TU_pool_l, TU_pool_u, na.rm = TRUE),
    uci   = max(TU_pool_l, TU_pool_u, na.rm = TRUE),
    pil   = if (all(is.finite(c(TU_pil, TU_piu)))) min(TU_pil, TU_piu) else NA_real_,
    piu   = if (all(is.finite(c(TU_pil, TU_piu)))) max(TU_pil, TU_piu) else NA_real_,
    stringsAsFactors = FALSE
  )
  
  tudf <- bind_rows(tudf_pool, tudf_studies)
  levels_order <- c("Pooled", ordered_labels)
  tudf$label_f <- factor(tudf$label, levels = levels_order)
  tudf$y <- as.numeric(tudf$label_f)  # numeric positions for plotting
  
  rd_table <- data.frame(Study = ordered_labels, RD = RD, RD_l = RD_l, RD_u = RD_u, stringsAsFactors = FALSE)
  
  # return tudf and diagnostics (rd table and any unmatched studies)
  # identify unmatched studies explicitly if data_in was provided
  unmatched <- NULL
  if (!is.null(data_in) && study_col %in% colnames(data_in)) {
    present_in_data <- ordered_labels %in% data_in[[study_col]]
    if (any(!present_in_data)) unmatched <- ordered_labels[!present_in_data]
  }
  
  return(list(tudf = tudf, rd = rd_table,
              pool = list(RD_pool = RD_pool, RD_pool_l = RD_pool_l, RD_pool_u = RD_pool_u),
              unmatched = unmatched))
}

# ---------------------------
# Plotting: uses y positions from tudf
# ---------------------------
plot_thresholds_forest <- function(tudf_list, outcome_name = "") {
  if (is.null(tudf_list) || is.null(tudf_list$tudf)) return(NULL)
  tudf <- tudf_list$tudf
  levels_order <- levels(tudf$label_f)
  bands <- data.frame(
    xmin = c(-Inf, -3, -2, -1, 1, 2, 3),
    xmax = c(-3, -2, -1, 1, 2, 3, Inf),
    ymin = 0.5, ymax = length(levels_order) + 0.5,
    fill = c("#CADBE3","#D7E4EA","#E4EDF1","#FFFFFF","#FFE1C2","#FFD6AD","#FFC285"),
    stringsAsFactors = FALSE
  )
  
  g <- ggplot(tudf, aes(x = TU, y = y)) +
    geom_rect(data = bands, aes(xmin = xmin, xmax = xmax, ymin = ymin, ymax = ymax, fill = fill),
              inherit.aes = FALSE, colour = NA, alpha = 0.6, show.legend = FALSE) +
    scale_fill_identity()
  
  g <- g +
    geom_errorbarh(data = subset(tudf, type == "study" & is.finite(lci) & is.finite(uci)),
                   aes(xmin = lci, xmax = uci), height = 0.2, colour = "grey50") +
    geom_point(data = subset(tudf, type == "study" & is.finite(TU)),
               aes(x = TU, y = y), size = 2.8, colour = "grey25")
  
  pooled <- subset(tudf, type == "pooled")
  if (nrow(pooled) == 1) {
    if (is.finite(pooled$pil) && is.finite(pooled$piu)) {
      g <- g + geom_segment(data = pooled,
                            aes(x = pil, xend = piu, y = y, yend = y),
                            inherit.aes = FALSE, colour = "red3", size = 1.2)
    }
    g <- g + geom_errorbarh(data = pooled, aes(y = y, xmin = lci, xmax = uci),
                            inherit.aes = FALSE, height = 0.4, colour = "black", size = 1.2) +
      geom_point(data = pooled, aes(x = TU, y = y), size = 5, shape = 23, fill = "black")
  }
  
  g <- g +
    scale_y_continuous(breaks = seq_along(levels_order), labels = levels_order, trans = "reverse") +
    scale_x_continuous(breaks = -3:3, limits = c(-4, 4), expand = expansion(mult = 0.02)) +
    labs(x = "Threshold Units", y = NULL,
         title = paste("Absolute Effects with Threshold Units", if (nzchar(outcome_name)) paste("-", outcome_name) else "")) +
    theme_bw() +
    theme(axis.text.y = element_text(size = 10), plot.title = element_text(hjust = 0.5))
  
  return(g)
}

# ---------------------------
# Shiny UI
# ---------------------------
ui <- fluidPage(
  tags$head(tags$style("body { background: #f8f9fa; } .well{background:#fff;border:1px solid #dee2e6;}")),
  titlePanel("Absolute Effects with Threshold Units - Meta-Analysis Results"),
  sidebarLayout(
    sidebarPanel(
      wellPanel(
        h4("Meta-Analysis Settings"),
        selectInput("outcome", "Select Outcome:",
                    choices = c("All-cause mortality" = "ACM",
                                "Cardiovascular mortality" = "CVM", 
                                "Major CV events" = "MCVE",
                                "Stroke" = "stroke",
                                "Kidney function loss" = "kidney",
                                "Syncope" = "syncope",
                                "Orthostatic hypotension" = "ortho",
                                "Falls" = "falls")),
        numericInput("baseline_per1000", "Baseline risk per 1000", value = 100, min = 1, step = 1),
        tags$hr(),
        h4("Decision Thresholds"),
        numericInput("thr_t1", "t1 (trivial→small)", value = 10, min = 1, step = 1),
        numericInput("thr_t2", "t2 (small→moderate)", value = 30, min = 2, step = 1),
        numericInput("thr_t3", "t3 (moderate→large)", value = 60, min = 3, step = 1),
        actionButton("plot_abs_effect", "Generate Plot", class = "btn btn-primary")
      )
    ),
    mainPanel(
      plotOutput("abs_plot", height = "700px"),
      tags$hr(),
      verbatimTextOutput("meta_summary")
    )
  )
)

# ---------------------------
# Server
# ---------------------------
server <- function(input, output, session) {
  
  run_meta_analysis <- reactive({
    outcome <- input$outcome
    
    # Subset data_clean and run meta-analysis per outcome (identical to your original branches)
    # NOTE: the code expects a data.frame named data_clean in the global environment.
    if (!exists("data_clean", envir = .GlobalEnv)) {
      stop("data_clean not found in global environment. Please create data_clean before running the app.")
    }
    
    data_env <- get("data_clean", envir = .GlobalEnv)
    
    if (outcome == "ACM") {
      data_sub <- subset(data_env, !is.na(ACM_low) & !is.na(ACM_control))
      meta_result <- metabin(
        event.e = ACM_low, n.e = nTOT_low,
        event.c = ACM_control, n.c = nTOT_control,
        studlab = Study, data = data_sub,
        sm = "RR", method = "Inverse", random = TRUE,
        common = FALSE, method.tau = "REML", incr = "TACC", prediction = TRUE
      )
    } else if (outcome == "CVM") {
      data_sub <- subset(data_env, !is.na(CVM_low) & !is.na(CVM_control))
      meta_result <- metabin(
        event.e = CVM_low, n.e = nTOT_low,
        event.c = CVM_control, n.c = nTOT_control,
        studlab = Study, data = data_sub,
        sm = "RR", method = "Inverse", random = TRUE,
        common = FALSE, method.tau = "REML", incr = "TACC", prediction = TRUE
      )
    } else if (outcome == "MCVE") {
      data_sub <- subset(data_env, !is.na(MCVE_low) & !is.na(MCVE_control))
      meta_result <- metabin(
        event.e = MCVE_low, n.e = nTOT_low,
        event.c = MCVE_control, n.c = nTOT_control,
        studlab = Study, data = data_sub,
        sm = "RR", method = "Inverse", random = TRUE,
        common = FALSE, method.tau = "REML", incr = "TACC", prediction = TRUE
      )
    } else if (outcome == "stroke") {
      data_sub <- subset(data_env, !is.na(stroke_low) & !is.na(stroke_control))
      meta_result <- metabin(
        event.e = stroke_low, n.e = nTOT_low,
        event.c = stroke_control, n.c = nTOT_control,
        studlab = Study, data = data_sub,
        sm = "RR", method = "Inverse", random = TRUE,
        common = FALSE, method.tau = "REML", incr = "TACC", prediction = TRUE
      )
    } else if (outcome == "kidney") {
      data_sub <- subset(data_env, !is.na(kidney_low) & !is.na(kidney_control))
      meta_result <- metabin(
        event.e = kidney_low, n.e = nTOT_kidney_low,
        event.c = kidney_control, n.c = nTOT_kidney_control,
        studlab = Study, data = data_sub,
        sm = "RR", method = "Inverse", random = TRUE,
        common = FALSE, method.tau = "REML", incr = "TACC", prediction = TRUE
      )
    } else if (outcome == "syncope") {
      data_sub <- subset(data_env, !is.na(syncope_low) & !is.na(syncope_control))
      meta_result <- metabin(
        event.e = syncope_low, n.e = nTOT_low,
        event.c = syncope_control, n.c = nTOT_control,
        studlab = Study, data = data_sub,
        sm = "RR", method = "Inverse", random = TRUE,
        common = FALSE, method.tau = "REML", incr = "TACC", prediction = TRUE
      )
    } else if (outcome == "ortho") {
      data_sub <- subset(data_env, !is.na(ortho_low) & !is.na(ortho_control))
      meta_result <- metabin(
        event.e = ortho_low, n.e = nTOT_ortho_low,
        event.c = ortho_control, n.c = nTOT_ortho_control,
        studlab = Study, data = data_sub,
        sm = "RR", method = "Inverse", random = TRUE,
        common = FALSE, method.tau = "REML", incr = "TACC", prediction = TRUE
      )
    } else if (outcome == "falls") {
      data_sub <- subset(data_env, !is.na(falls_low) & !is.na(falls_control))
      meta_result <- metabin(
        event.e = falls_low, n.e = nTOT_falls_low,
        event.c = falls_control, n.c = nTOT_falls_control,
        studlab = Study, data = data_sub,
        sm = "RR", method = "Inverse", random = TRUE,
        common = FALSE, method.tau = "REML", incr = "TACC", prediction = TRUE
      )
    } else {
      meta_result <- NULL
    }
    
    return(meta_result)
  })
  
  # Compute TU dataframe when button clicked
  tudf <- eventReactive(input$plot_abs_effect, {
    meta_res <- run_meta_analysis()
    if (is.null(meta_res)) return(NULL)
    compute_TU_df_from_meta(meta_res,
                            baseline_per1000 = input$baseline_per1000,
                            t1 = input$thr_t1,
                            t2 = input$thr_t2,
                            t3 = input$thr_t3,
                            data_in = if (exists("data_clean", envir = .GlobalEnv)) get("data_clean", envir = .GlobalEnv) else NULL,
                            study_col = "Study",
                            year_col_candidates = c("Year...4", "Year"))
  })
  
  # Render plot
  output$abs_plot <- renderPlot({
    df_list <- tudf()
    if (is.null(df_list)) return(NULL)
    plot_thresholds_forest(df_list, input$outcome)
  })
  
  # Render meta-analysis summary text (with additional diagnostics)
  output$meta_summary <- renderPrint({
    meta_res <- run_meta_analysis()
    if (is.null(meta_res)) {
      cat("No meta-analysis results available for the selected outcome.\n")
      return()
    }
    # Basic summary
    cat("Meta-Analysis Summary:\n")
    cat("======================\n")
    cat("Outcome:", input$outcome, "\n")
    cat("Number of studies:", length(meta_res$studlab), "\n")
    if (!is.null(meta_res$TE.random)) {
      cat("Pooled RR (exp(TE.random)):", round(exp(meta_res$TE.random), 3), "\n")
      cat("95% CI (RR):", round(exp(meta_res$lower.random), 3), "to", round(exp(meta_res$upper.random), 3), "\n")
    }
    if (!is.null(meta_res$lower.predict)) {
      cat("Prediction interval (RR):", round(exp(meta_res$lower.predict), 3), "to", round(exp(meta_res$upper.predict), 3), "\n")
    }
    cat("I^2:", if (!is.null(meta_res$I2)) round(meta_res$I2, 2) else NA, "\n")
    cat("Tau^2:", if (!is.null(meta_res$tau2)) round(meta_res$tau2, 4) else NA, "\n")
    
    # RD & matching diagnostics if tudf available
    df_list <- tudf()
    if (!is.null(df_list)) {
      pool <- df_list$pool
      cat("\nPooled RD (per 1000):",
          formatC(pool$RD_pool, digits = 3, format = "f"),
          " (", formatC(pool$RD_pool_l, digits = 3, format = "f"),
          " to ", formatC(pool$RD_pool_u, digits = 3, format = "f"), ")\n", sep = "")
      
      if (!is.null(df_list$unmatched) && length(df_list$unmatched) > 0) {
        cat("\nWarning: The following studies in the meta object were NOT found in data_clean$Study (they will be plotted in meta order):\n")
        cat(paste(df_list$unmatched, collapse = ", "), "\n")
      }
    }
  })
}

shinyApp(ui, server)


remove(list = ls())
