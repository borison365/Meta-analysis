library(grid)
library(readxl)
library(dplyr)
library(meta)
library(tidyverse)

# load our dataset

f <- read_excel("subgroup_analaysis 1/11414789/follow up KQ1_updated.xlsx")

d<- read_excel("subgroup_analaysis 1/11414789/ACP KQ1_all studies v7_Final_DP(bp goals).xlsx")
l <- read_csv("subgroup_analaysis 1/11414789/reshaped_main_with_all_RoB(Sheet1).csv")

#  Merge them 
merged <- l |>
  left_join(d, by = "Study") |>
  left_join(f, by = "Study")      # third table

merged <- merged %>%
  mutate(`Lower (DBP)` = as.numeric(as.character(`Lower (DBP)`))) %>%
  filter(!is.na(`Lower (DBP)`))


merged <- merged %>%
  mutate(
    DBP_Cut_Off = case_when(
      !is.na(`Lower (DBP)`) & `Lower (DBP)` <80 ~ "<80",
      !is.na(`Lower (DBP)`) & `Lower (DBP)` >=80 ~ ">=80",
      TRUE ~ NA_character_
    )
  )

merged_mk <- merged %>%
  mutate(`Lower (DBP)` = as.numeric(as.character(`Lower (DBP)`))) %>%
  filter(!is.na(`Lower (DBP)`))

colnames(merged_mk)
# --- Keep descriptive variables ---

num_cols <- c("ACM_low", "nTOT_low", "ACM_control", "nTOT_control")

# force numeric conversion
merged_mk[num_cols] <- lapply(merged_mk[num_cols], \(x) as.numeric(as.character(x)))
colnames(merged_mk)

descriptive_vars <- c(
  "age (mean)", "female (%)", "high CV risk (%)", "DM (%)",
  "DBP_Cut_Off",
  "FUP_ACM", "FUP_CVM", "FUP_MCVE",
  "FUP_stroke", "FUP_kidney", "FUP_syncope",
  "FUP_ortho", "FUP_falls",
  "FUP_qol_phy", "FUP_qol_ment",
  "FUP_qol_EQ5D", "FUP_qol_EQVAS"
)
meta_mcve <- merged_mk%>%
  select(Study, all_of(num_cols), all_of(descriptive_vars))

view(meta_mcve)
colnames(meta_mcve)

# 2. Convert to numeric first
meta_mcve[num_cols] <- lapply(meta_mcve[num_cols], function(x) as.numeric(as.character(x)))

# 4. Remove rows with any NA in numeric columns after conversion
meta_mcv <- meta_mcve %>%
  filter(complete.cases(across(all_of(num_cols))))

view(meta_mcv) # suppose to return 6 obs.


meta_make <- meta_mcv %>%
  mutate(across(all_of(num_cols), ~as.numeric(as.character(.)))) %>%
  mutate(DBP_Cut_Off = trimws(as.character(DBP_Cut_Off))) %>%
  filter(complete.cases(across(c(all_of(num_cols), "DBP_Cut_Off")))) 

# arrange studies in the order of bp goal from lower to higher
meta_make <- meta_make|>
  mutate(
    DBP_Cut_Off = factor(
      DBP_Cut_Off,
      levels = c("<80", ">=80")
    )
  ) |>
  arrange(DBP_Cut_Off)

view(meta_make)


# Ensure subgroup variable is quoted correctly
meta_l <- metabin(
  event.e = ACM_low,
  n.e = nTOT_low,
  event.c = ACM_control,
  n.c = nTOT_control,
  studlab = Study,
  data = meta_make,
  sm = "RR",
  method = "Inverse",
  common = FALSE,
  random = TRUE,
  subgroup = meta_make$DBP_Cut_Off,
  method.tau = "REML",
  incr = "TACC"
)


forest(
  meta_l,
  print.byvar = TRUE,
  text.random = "Overall (Random effects)",
  prediction = TRUE,
  print.I2 = TRUE,
  
  smlab = "Risk Ratio (95% CI)",
  xlab = "Risk Ratio"
)

#Add descriptive variables to meta object 

meta_l$`age (mean)`       <- meta_l$`age (mean)`
meta_l$`female (%)`       <- meta_l$`female (%)`
meta_l$`high CV risk (%)` <- meta_l$`high CV risk (%)`
meta_l$`DM (%)`           <- meta_l$`DM (%)` 
meta_l$`FUP_ACM`        <- meta_l$`FUP_ACM`

# Forest plot in pdf

forest(
  meta_l,
  label.e = "Lower BP goals",
  label.c = "Higher BP goals",
  
  leftcols = c("studlab",
               "event.e", "n.e", "event.c", "n.c",
               "age (mean)", "female (%)", "high CV risk (%)",
               "DM (%)", "FUP_ACM"),
  leftlabs = c("Study",
               "Events", "Total", "Events", "Total",
               "Age (mean)", "Female (%)", "High CV risk (%)",
               "DM (%)", "FU (months)"),
  
  comb.fixed = FALSE,
  comb.random = TRUE,
  print.study.ci = TRUE,
  showweights = TRUE,
  digits = 2,
  colgap.left = "7.5mm",
  fontsize = 10,
  plotwidth = "9cm",
  xlim = c(0.1,10),
  pooled.events = TRUE,
  print.I2.ci = TRUE,
  print.tau2 = TRUE,
  overall.hetstat = TRUE,
  test.overall = TRUE,
  prediction = TRUE
)

# Title
grid.text(
  "Mortality Events by Diastolic BP Cut-off",
  x = unit(0.5, "npc"),
  y = unit(0.93, "npc"),
  gp = gpar(fontsize = 13, fontface = "bold")
)
dev.off()
remove(list = ls())
