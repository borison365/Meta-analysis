
######################## RoB Analysis for studies with BP between 130-139 ####################################
##############################################################################################################


install.packages("tidyverse")
library(grid)
library(readxl)
library(dplyr)
library(meta)
library(tidyverse)

# load our dataset

f <- read_excel("subgroup_analaysis 1/11414789/follow up KQ1_updated.xlsx")
d<- read_excel("subgroup_analaysis 1/11414789/ACP KQ1_all studies v7_Final_DP(bp goals).xlsx")
l <- read_csv("subgroup_analaysis 1/11414789/reshaped_main_with_all_RoB(Sheet1).csv")

#  Merge them 
merged <- l |>
  left_join(d, by = "Study") |>
  left_join(f, by = "Study")      # third table

merged <- merged %>%
  mutate(`Lower (SBP)` = as.numeric(as.character(`Lower (SBP)`))) %>%
  filter(!is.na(`Lower (SBP)`))

merged <- merged %>%
  mutate(
    SBP_goal = case_when(
      !is.na(`Lower (SBP)`) & `Lower (SBP)` >= 140 & `Lower (SBP)` < 150 ~ "140-149",
      TRUE ~ NA_character_
    )
  )

# create column for RoB subgroup syncope

merged_cl  <- merged %>%
  mutate(
    RoB_ortho_140_149 = case_when(
      RoB_ortho_Overall == "High" ~ "Some concern to high",
      RoB_ortho_Overall == "Some concerns" ~ "Some concern to high",
      RoB_ortho_Overall == "Low" ~ "Low",
      TRUE ~ NA_character_   # catch any unexpected values
    )
  )

# --- Keep descriptive variables ---

num_cols <- c("ortho_low", "nTOT_ortho_low", "ortho_control", "nTOT_ortho_control")

descriptive_vars <- c(
  
  "SBP_goal", "RoB_ortho_140_149" 
)

meta_data <- merged_cl%>%
  select(Study, all_of(num_cols), all_of(descriptive_vars))
View(meta_data)

#Remove rows where any event column is NA after conversion

meta_dw <- meta_data %>%
  filter(complete.cases(across(all_of(num_cols))))

# 2. Convert to numeric first
meta_dw[num_cols] <- lapply(meta_dw[num_cols], function(x) as.numeric(as.character(x)))

# 4. Remove rows with any NA in numeric columns
meta_df <- meta_dw %>%
  filter(complete.cases(across(all_of(num_cols))))

# Compare the difference bwn studies with SBP and outcomes
View(meta_df)

meta_clin <- meta_df %>%
  # Force numeric for all meta-analysis variables
  mutate(across(all_of(num_cols), ~as.numeric(as.character(.)))) %>%
  # Ensure subgroup variable is a clean character string
  mutate(SBP_goal = trimws(as.character(SBP_goal))) %>%
  # Keep only rows where ALL required variables are non-NA
  filter(complete.cases(across(c(all_of(num_cols), "SBP_goal"))))

view(meta_clin) # end analysis