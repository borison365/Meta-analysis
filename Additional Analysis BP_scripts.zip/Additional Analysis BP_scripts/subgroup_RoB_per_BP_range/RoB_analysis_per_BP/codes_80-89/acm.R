
######################## RoB Analysis for studies with BP between 130-139 ####################################
##############################################################################################################


install.packages("tidyverse")
library(grid)
library(readxl)
library(dplyr)
library(meta)
library(tidyverse)

# load our dataset

f <- read_excel("subgroup_analaysis 1/11414789/follow up KQ1_updated.xlsx")
d<- read_excel("subgroup_analaysis 1/11414789/ACP KQ1_all studies v7_Final_DP(bp goals).xlsx")
l <- read_csv("subgroup_analaysis 1/11414789/reshaped_main_with_all_RoB(Sheet1).csv")

#  Merge them 
merged <- l |>
  left_join(d, by = "Study") |>
  left_join(f, by = "Study")      # third table

merged <- merged %>%
  mutate(`Lower (DBP)` = as.numeric(as.character(`Lower (DBP)`))) %>%
  filter(!is.na(`Lower (DBP)`))

merged <- merged %>%
  mutate(
    DBP_goal = case_when(
      !is.na(`Lower (DBP)`) & `Lower (DBP)` >= 80 & `Lower (DBP)` < 90 ~ "80-89",
      TRUE ~ NA_character_
    )
  )

# create column for RoB subgroup syncope

merged_cl  <- merged %>%
  mutate(
    RoB_ACM_80_89 = case_when(
      RoB_ACM_Overall == "High" ~ "Some concern to high",
      RoB_ACM_Overall == "Some concerns" ~ "Some concern to high",
      RoB_ACM_Overall == "Low" ~ "Low",
      TRUE ~ NA_character_   # catch any unexpected values
    )
  )

# --- Keep descriptive variables ---

num_cols <- c("ACM_low", "nTOT_low", "ACM_control", "nTOT_control")

descriptive_vars <- c(
  
  "DBP_goal", "RoB_ACM_80_89" 
)

meta_data <- merged_cl%>%
  select(Study, all_of(num_cols), all_of(descriptive_vars))
View(meta_data)

#Remove rows where any event column is NA after conversion

meta_dw <- meta_data %>%
  filter(complete.cases(across(all_of(num_cols))))

# 2. Convert to numeric first
meta_dw[num_cols] <- lapply(meta_dw[num_cols], function(x) as.numeric(as.character(x)))

# 4. Remove rows with any NA in numeric columns
meta_df <- meta_dw %>%
  filter(complete.cases(across(all_of(num_cols))))

# Compare the difference bwn studies with SBP and outcomes
View(meta_df)

meta_clin <- meta_df %>%
  # Force numeric for all meta-analysis variables
  mutate(across(all_of(num_cols), ~as.numeric(as.character(.)))) %>%
  # Ensure subgroup variable is a clean character string
  mutate(DBP_goal = trimws(as.character(DBP_goal))) %>%
  # Keep only rows where ALL required variables are non-NA
  filter(complete.cases(across(c(all_of(num_cols), "DBP_goal"))))

view(meta_clin) # only studies with bp goal and outcome for RoB group
colnames(meta_clin)

# to compute the number of studies
k_studies <- length(unique(meta_clin$Study))

# run the meta with outcome variable of interest kidney & subgroup

meta_str <- metabin(event.e = ACM_low, n.e = nTOT_low,
                    event.c = ACM_control, n.c = nTOT_control,
                    studlab = Study,
                    data = meta_clin,
                    sm = "RR",
                    method = "Inverse",
                    common = FALSE,
                    subgroup = RoB_ACM_80_89,
                    random = TRUE,
                    method.tau = "REML", incr = "TACC")

forest(meta_str,
       pooled.events = TRUE,
       label.e = "Lower BP goals",
       label.c = "Higher BP goals",
       colgap.left = "6.5mm",
       prediction = TRUE,
       plotwidth = "7cm",
       rows.gr = 6
       
)

grid.text("RoB Sensitivity Analysis of Mortality Events with DBP 80-89",
          x = unit(0.5, "npc"),
          y = unit(0.93, "npc"),
          gp = gpar(fontsize = 14, fontface = "bold"))
grid.text(
  paste("Number of studies (k):", k_studies),
  x = unit(0.02, "npc"),   # left margin
  y = unit(0.06, "npc"),   # bottom margin
  just = c("left", "bottom"),
  gp = gpar(fontsize = 10)
)
dev.off()

remove(list = ls())
